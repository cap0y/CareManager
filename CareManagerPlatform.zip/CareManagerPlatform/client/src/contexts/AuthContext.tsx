// @ts-nocheck
import { createContext, useContext, useState, useEffect, ReactNode } from "react";
// @ts-ignore – local Firebase wrapper
import { auth, googleProvider } from "@/firebase";
// @ts-ignore
import {
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
  setPersistence,
  browserLocalPersistence,
  updateProfile,
} from "firebase/auth";

// 사용자 타입 정의
export type UserType = 'customer' | 'careManager' | 'admin';
export type UserGrade = 'bronze' | 'silver' | 'gold' | 'platinum';

// 상수들을 최상단으로 이동하여 어디서든 접근 가능하게 함
export const SUPER_ADMIN_EMAIL = "decom2soft@gmail.com";

// 슈퍼 관리자 여부 확인 유틸리티 함수
export function isSuperAdmin(email: string | null): boolean {
  if (!email) return false;
  return email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
}

// 사용자 객체에 슈퍼 관리자 권한 적용 함수
export function ensureAdminRights(user: any): any {
  if (!user || !user.email) return user;
  
  // 슈퍼 관리자인 경우 항상 admin 권한 부여
  if (isSuperAdmin(user.email)) {
    console.log("슈퍼 관리자 권한 강제 적용:", user.email);
    return {
      ...user,
      userType: 'admin' as UserType,
      isApproved: true
    };
  }
  
  return user;
}

// Kakao 로그인 설정
const KAKAO_REST_KEY = "4d53287fcaa83a038163adf3b057b802";
const KAKAO_REDIRECT_URI = `${window.location.origin}/oauth/kakao/callback`;
const KAKAO_SDK_URL = "https://developers.kakao.com/sdk/js/kakao.js";

interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  userType: UserType;
  grade?: UserGrade;
  isApproved?: boolean;
}

interface AuthProviderProps {
  children: ReactNode;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean; // 사용자 로딩 상태 추가
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  login: (user: User) => void; // For email/password flows
  emailPasswordLogin: (email: string, password: string) => Promise<void>; // 서버 API 로그인 추가
  logout: () => Promise<void>;
  googleLogin: () => Promise<void>;
  kakaoLogin: () => Promise<void>;
  updateUserType: (userType: UserType) => Promise<void>;
  updateUserPhoto: (photoURL: string) => Promise<boolean>; // 새로운 함수 추가
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

// 이메일로 사용자 타입 결정 (실제로는 API에서 받아온 값을 사용)
function determineUserType(email: string | null): UserType {
  if (!email) return "customer";
  if (email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) return "admin";
  return "customer";
}

// 로컬 스토리지에 사용자 타입 저장
function saveUserType(email: string, userType: UserType) {
  try {
    // 슈퍼 관리자 이메일인 경우 항상 admin으로 저장
    if (email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
      userType = 'admin';
    }
    
    const userTypes = JSON.parse(localStorage.getItem("user_types") || "{}");
    userTypes[email] = userType;
    localStorage.setItem("user_types", JSON.stringify(userTypes));
    console.log(`사용자 타입 저장됨: ${email} => ${userType}`);
  } catch (error) {
    console.error("Error saving user type to local storage:", error);
  }
}

// 로컬 스토리지에서 사용자 타입 가져오기
function getSavedUserType(email: string): UserType | null {
  try {
    const userTypes = JSON.parse(localStorage.getItem("user_types") || "{}");
    return userTypes[email] || null;
  } catch (error) {
    console.error("Error getting user type from local storage:", error);
    return null;
  }
}

// Kakao SDK 로드 함수
async function loadKakaoSdk() {
  return new Promise<void>((resolve, reject) => {
    if (window.Kakao) {
      if (!window.Kakao.isInitialized()) {
        try {
          window.Kakao.init(KAKAO_REST_KEY);
          console.log("Kakao SDK 초기화 완료");
        } catch (error) {
          console.error("Kakao SDK 초기화 실패:", error);
        }
      }
      resolve();
      return;
    }

    const script = document.createElement("script");
    script.src = KAKAO_SDK_URL;
    
    script.onload = () => {
      if (window.Kakao) {
        try {
          window.Kakao.init(KAKAO_REST_KEY);
          console.log("Kakao SDK 로드 및 초기화 성공");
          resolve();
        } catch (error) {
          console.error("Kakao SDK 초기화 중 오류:", error);
          reject(error);
        }
      } else {
        console.error("Kakao SDK가 로드되었지만 window.Kakao 객체를 찾을 수 없음");
        reject(new Error("Kakao SDK 로드 실패"));
      }
    };
    
    script.onerror = (error) => {
      console.error("Kakao SDK 로드 실패:", error);
      reject(new Error("Kakao SDK 로드 실패"));
    };
    
    document.head.appendChild(script);
  });
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true); // 사용자 로딩 상태 추가

  useEffect(() => {
    // 이벤트 리스너 등록: 로그인 모달 표시
    const handleShowLogin = () => {
      console.log("로그인 모달 표시 이벤트 감지");
      setShowAuthModal(true);
    };
    
    window.addEventListener("showLogin", handleShowLogin);
    
    // 이벤트 리스너 정리
    return () => {
      window.removeEventListener("showLogin", handleShowLogin);
    };
  }, []);

  useEffect(() => {
    // 로컬 스토리지 초기화 함수
    const resetLocalStorage = () => {
      try {
        console.log("로컬 스토리지 초기화 및 슈퍼 관리자 설정 확인");
        
        // 기존 사용자 타입 정보 유지
        const existingUserTypes = localStorage.getItem("user_types");
        let userTypes = existingUserTypes ? JSON.parse(existingUserTypes) : {};
        
        // 슈퍼 관리자 설정 추가 (기존 설정 덮어쓰지 않음)
        if (!userTypes[SUPER_ADMIN_EMAIL]) {
          userTypes[SUPER_ADMIN_EMAIL] = 'admin';
          localStorage.setItem("user_types", JSON.stringify(userTypes));
          console.log("슈퍼 관리자 설정 완료:", userTypes);
        }
      } catch (error) {
        console.error("로컬 스토리지 초기화 오류:", error);
      }
    };
    
    // 앱 시작 시 한 번 초기화
    resetLocalStorage();
    
    // 인증 지속성 설정 - LOCAL로 설정
    setPersistence(auth, browserLocalPersistence)
      .then(() => {
        console.log("Firebase 인증 지속성이 LOCAL로 설정되었습니다.");
      })
      .catch((error) => {
        console.error("인증 지속성 설정 오류:", error);
      });
    
    // Firebase auth state listener
    const unsub = onAuthStateChanged(auth, (firebaseUser: FirebaseUser | null) => {
      console.log("Firebase 인증 상태 변경:", {
        firebaseUser: firebaseUser ? {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName
        } : null
      });
      
      if (firebaseUser) {
        const mappedUser = mapFirebaseUser(firebaseUser);
        console.log("매핑된 사용자:", mappedUser);
        setUser(mappedUser);
        
        // 로그인 성공 시 체크아웃 페이지 리다이렉트 처리
        const checkoutData = localStorage.getItem('checkoutData');
        if (checkoutData) {
          console.log("로그인 성공 후 체크아웃 데이터 발견, 체크아웃 페이지로 이동");
          
          // 인증 상태가 완전히 설정된 후 이동하도록 지연
          setTimeout(() => {
            // 페이지 새로고침 없이 이동
            // 체크아웃 페이지에서 인증 상태를 확인할 수 있도록 충분한 시간 지연
            setShowAuthModal(false);
            window.location.href = "/checkout";
          }, 1000); // 1초로 지연 시간 증가
        }
      } else {
        console.log("사용자 로그아웃 또는 인증되지 않음");
        setUser(null);
      }
      setIsLoading(false); // 인증 상태 확인 완료
    });
    
    // 리디렉션 결과 처리
    const handleRedirectResult = async () => {
      try {
        // 리디렉션 결과 확인
        const result = await getRedirectResult(auth);
        
        if (result && result.user) {
          console.log("구글 로그인 리디렉션 성공:", result.user.email);
          
          // decom2soft@gmail.com 이메일 직접 확인
          if (result.user.email?.toLowerCase() === "decom2soft@gmail.com") {
            console.log("★★★ 슈퍼 관리자 계정 감지: decom2soft@gmail.com ★★★");
            
            // 로컬 스토리지 완전히 초기화
            localStorage.clear();
            
            // 관리자 권한 설정
            const userTypes = {};
            userTypes[result.user.email] = 'admin';
            localStorage.setItem("user_types", JSON.stringify(userTypes));
            console.log("관리자 권한 설정 완료:", JSON.stringify(userTypes));
            
            // 직접 관리자 페이지로 이동
            setTimeout(() => {
              console.log("관리자 페이지로 강제 이동합니다...");
              window.location.href = "/profile";
            }, 1000);
          }
          
          // 이전 페이지로 이동 (선택적)
          if (localStorage.getItem('pending_admin_check')) {
            localStorage.removeItem('pending_admin_check');
            window.location.href = "/profile"; // 프로필 페이지로 강제 이동
          }
        }
      } catch (error) {
        console.error("리디렉션 결과 처리 오류:", error);
      }
    };
    
    // 리디렉션 결과 처리 실행
    handleRedirectResult();

    // Load Kakao SDK once
    loadKakaoSdk();

    // 로컬 스토리지에 저장된 슈퍼 관리자 정보 재설정
    try {
      const userTypes = JSON.parse(localStorage.getItem("user_types") || "{}");
      Object.keys(userTypes).forEach(email => {
        if (email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
          userTypes[email] = 'admin';
          console.log(`로컬 스토리지에서 슈퍼 관리자 감지 및 재설정: ${email}`);
        }
      });
      localStorage.setItem("user_types", JSON.stringify(userTypes));
    } catch (error) {
      console.error("로컬 스토리지 업데이트 오류:", error);
    }

    return () => unsub();
  }, []);

  const mapFirebaseUser = (fbUser: FirebaseUser): User => {
    // 슈퍼 관리자 이메일 직접 확인 - 대소문자 구분 없이
    const email = fbUser.email || "";
    
    // 슈퍼 관리자 확인 로직 강화
    let userType: UserType = 'customer';
    
    // 디버깅을 위한 상세 로그 추가
    console.log("Firebase 사용자 매핑 - 이메일:", email);
    
    // decom2soft@gmail.com 계정은 무조건 admin 권한 부여 (대소문자 무시)
    if (email.toLowerCase() === "decom2soft@gmail.com") {
      console.log("decom2soft@gmail.com 계정 감지 - 무조건 admin으로 설정");
      userType = 'admin';
      
      // 로컬 스토리지 초기화 및 admin 설정
      localStorage.clear();
      const userTypes = {};
      userTypes[email] = 'admin';
      localStorage.setItem("user_types", JSON.stringify(userTypes));
      
      // 1초 후에 페이지 새로고침하여 확실하게 적용
      setTimeout(() => window.location.reload(), 1000);
      
      return {
        uid: fbUser.uid,
        email: fbUser.email,
        displayName: fbUser.displayName,
        photoURL: fbUser.photoURL,
        userType: 'admin',
        grade: 'platinum',
        isApproved: true,
      };
    }
    
    // 슈퍼 관리자 여부 확인 - isSuperAdmin 유틸리티 함수 사용
    if (isSuperAdmin(email)) {
      userType = 'admin';
      console.log("Firebase 인증 후 슈퍼 관리자 감지 - admin 타입 설정");
      
      // 강제로 로컬 스토리지 업데이트
      try {
        // 기존 로컬 스토리지 초기화
        localStorage.clear();
        
        const userTypes = {};
        userTypes[email] = 'admin';
        localStorage.setItem("user_types", JSON.stringify(userTypes));
        console.log("슈퍼 관리자 로컬 스토리지 강제 업데이트");
      } catch (e) {
        console.error("로컬 스토리지 업데이트 오류", e);
      }
    } else {
      // 기존 저장된 유형이 있으면 사용
      userType = getSavedUserType(email) || determineUserType(email);
    }
    
    console.log("최종 설정된 사용자 타입:", userType);
    
    const mappedUser = {
      uid: fbUser.uid,
      email: fbUser.email,
      displayName: fbUser.displayName,
      photoURL: fbUser.photoURL,
      userType,
      grade: 'bronze',  // 기본 등급 설정
      isApproved: userType !== 'careManager' || false,  // 케어매니저가 아니면 승인 불필요
    };
    
    // 슈퍼 관리자 권한 최종 확인 및 적용
    return ensureAdminRights(mappedUser);
  };

  const login = (localUser: User) => {
    // 사용자 타입 저장 (기존 타입이 있으면 그대로 사용)
    if (localUser.email) {
      console.log("로그인 시도 - 원본 유저 정보:", localUser);
      
      // 슈퍼 관리자 확인 강제 적용
      let userType = localUser.userType;
      if (localUser.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
        userType = 'admin';
        console.log("로그인 함수에서 슈퍼 관리자 감지! 강제 admin 설정");
        
        // 관리자 사용자 타입을 강제로 설정 - 기존 객체 속성 직접 수정
        localUser.userType = 'admin';
      } else {
        userType = userType || determineUserType(localUser.email);
      }
      
      // 타입 정보가 없는 경우 기본 타입으로 추가
      const updatedUser = {
        ...localUser,
        userType,
        grade: localUser.grade || 'bronze',
        isApproved: localUser.isApproved !== undefined ? localUser.isApproved : (userType !== 'careManager' || false),
      };
      
      console.log("업데이트된 유저 정보:", updatedUser);
      
      // 로컬 스토리지에 사용자 타입 저장
      saveUserType(localUser.email, userType);
      
      // 사용자 정보를 업데이트된 내용으로 설정
      setUser(updatedUser);
      setShowAuthModal(false);
    } else {
      setUser(localUser);
      setShowAuthModal(false);
    }
  };

  // 서버 API를 통한 이메일/비밀번호 로그인
  const emailPasswordLogin = async (email: string, password: string) => {
    try {
      console.log("서버 API 로그인 시도:", email);
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error("로그인 API 오류:", errorData);
        throw new Error(errorData.error || '로그인에 실패했습니다.');
      }

      const data = await response.json();
      console.log("서버 API 로그인 성공:", data);

      if (data.user) {
        // 슈퍼 관리자 확인 로직 - 명확한 비교 추가
        if (email && email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) {
          console.log(`슈퍼 관리자 감지: ${email}`);
          // 직접 userType 속성 설정
          data.user.userType = 'admin';
          console.log("관리자로 사용자 타입 설정:", data.user);
          
          // 강제로 로컬 스토리지 업데이트
          try {
            const userTypes = JSON.parse(localStorage.getItem("user_types") || "{}");
            userTypes[email] = 'admin';
            localStorage.setItem("user_types", JSON.stringify(userTypes));
            console.log("이메일 로그인: 슈퍼 관리자 로컬 스토리지 강제 업데이트");
          } catch (e) {
            console.error("로컬 스토리지 업데이트 오류", e);
          }
        }
        
        login(data.user);
        setShowAuthModal(false);
        return data.user;
      } else {
        throw new Error('서버에서 사용자 정보를 반환하지 않았습니다.');
      }
    } catch (error) {
      console.error("이메일/비밀번호 로그인 오류:", error);
      throw error;
    }
  };

  const googleLogin = async () => {
    try {
      // 로그인 시작 전에 decom2soft@gmail.com 확인을 위한 상태 설정
      localStorage.setItem('pending_admin_check', 'true');
      
      console.log("구글 로그인 시작: 페이지 새로고침 방식으로 인증 진행");
      
      // 팝업 방식으로 로그인 (정책상 iframe 금지)
      await signInWithPopup(auth, googleProvider);
      
      // 인증 UI 닫기
      setShowAuthModal(false);
    } catch (error) {
      console.error("구글 로그인 오류:", error);
    }
  };

  const kakaoLogin = async () => {
    // Ensure SDK init
    // @ts-ignore
    if (!window.Kakao || !window.Kakao.isInitialized()) loadKakaoSdk();

    // @ts-ignore
    window.Kakao.Auth.authorize({
      redirectUri: KAKAO_REDIRECT_URI,
      throughTalk: false,
    });
  };

  const logout = async () => {
    // Firebase 로그아웃
    await signOut(auth);
    
    // 로컬 스토리지의 인증 관련 데이터 삭제
    localStorage.removeItem("socket_session");
    localStorage.removeItem("current_chat_request");
    
    // 상태 초기화
    setUser(null);
  };
  
  // 사용자 타입 업데이트
  const updateUserType = async (userType: UserType) => {
    if (!user || !user.email) return;
    
    try {
      // API 호출하여 사용자 타입 업데이트 (실제 API 호출 코드로 대체 필요)
      const response = await fetch(`/api/users/${user.uid}/change-type`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userType }),
      });
      
      if (!response.ok) {
        throw new Error('사용자 타입 업데이트에 실패했습니다.');
      }
      
      // 로컬 스토리지에 사용자 타입 저장
      saveUserType(user.email, userType);
      
      // 상태 업데이트
      setUser({
        ...user,
        userType,
        isApproved: userType !== 'careManager' || false,  // 케어매니저로 변경 시 승인 필요
      });
    } catch (error) {
      console.error('사용자 타입 업데이트 오류:', error);
      throw error;
    }
  };

  // 사용자 프로필 사진 업데이트 
  const updateUserPhoto = async (photoURL: string) => {
    if (!user) return false;
    
    try {
      // Firebase 사용자 프로필 업데이트
      const currentUser = auth.currentUser;
      if (currentUser) {
        await updateProfile(currentUser, { photoURL });
      }
      
      // 상태 업데이트
      setUser({
        ...user,
        photoURL
      });
      
      // 서버 API 호출 - 케어 매니저 프로필 사진도 업데이트
      try {
        await fetch(`/api/users/${user.uid}/profile-photo`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ photoURL }),
        });
      } catch (error) {
        console.error('서버 프로필 사진 업데이트 오류:', error);
      }

      return true;
    } catch (error) {
      console.error('사용자 프로필 사진 업데이트 오류:', error);
      throw error;
    }
  };

  const value: AuthContextType = {
    user,
    isLoading, // 사용자 로딩 상태 추가
    showAuthModal,
    setShowAuthModal,
    login,
    emailPasswordLogin,
    logout,
    googleLogin,
    kakaoLogin,
    updateUserType,
    updateUserPhoto,  // 새로운 함수 추가
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};