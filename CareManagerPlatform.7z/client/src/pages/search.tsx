import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import CareManagerCard from "@/components/care-manager-card";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import type { Service, CareManager } from "@shared/schema";

const Search = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedService, setSelectedService] = useState("");
  const [sortBy, setSortBy] = useState("rating");
  const [location] = useLocation();
  const { user, setShowAuthModal } = useAuth();
  const { toast } = useToast();

  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  const { data: careManagers = [] } = useQuery<CareManager[]>({
    queryKey: ['/api/care-managers'],
  });

  // Parse URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const query = urlParams.get('q') || '';
    const service = urlParams.get('service') || '';
    
    setSearchQuery(query);
    setSelectedService(service);
  }, [location]);

  const filteredManagers = careManagers.filter(manager => {
    const matchesSearch = !searchQuery || 
      manager.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      manager.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesService = !selectedService || 
      (manager.services as string[]).includes(selectedService);
    
    return matchesSearch && matchesService;
  });

  const sortedManagers = [...filteredManagers].sort((a, b) => {
    switch (sortBy) {
      case 'rating':
        return b.rating - a.rating;
      case 'reviews':
        return b.reviews - a.reviews;
      case 'experience':
        return parseInt(b.experience) - parseInt(a.experience);
      case 'price':
        return a.hourlyRate - b.hourlyRate;
      default:
        return 0;
    }
  });

  const handleBookingClick = (manager: CareManager) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    toast({
      title: "예약 요청",
      description: `${manager.name} 케어 매니저에게 예약을 요청하시겠습니까?`,
    });
  };

  const handleMessageClick = (manager: CareManager) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    toast({
      title: "문의 요청",
      description: `${manager.name} 케어 매니저에게 문의하시겠습니까?`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-20">
      {/* Search Header */}
      <div className="bg-white/90 backdrop-blur-sm shadow-sm px-4 py-6 sticky top-0 z-30">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center space-x-3 mb-4">
            <div className="flex-1 relative">
              <Input
                placeholder="지역, 서비스명으로 검색해보세요"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 py-3 border-gray-300 rounded-xl text-sm focus:ring-2 focus:ring-purple-500"
              />
              <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-sm"></i>
            </div>
            <Button variant="outline" className="px-4 py-3 rounded-xl">
              <i className="fas fa-filter"></i>
            </Button>
          </div>
          
          {/* Filter Chips */}
          <div className="flex space-x-2 overflow-x-auto pb-2">
            <Button
              variant={selectedService === '' ? "default" : "outline"}
              size="sm"
              className="rounded-full whitespace-nowrap"
              onClick={() => setSelectedService('')}
            >
              전체
            </Button>
            {services.map((service) => (
              <Button
                key={service.id}
                variant={selectedService === service.name ? "default" : "outline"}
                size="sm"
                className="rounded-full whitespace-nowrap"
                onClick={() => setSelectedService(selectedService === service.name ? '' : service.name)}
              >
                {service.name}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Filter Options */}
      <div className="bg-white/90 backdrop-blur-sm border-b px-4 py-3">
        <div className="max-w-4xl mx-auto">
          <div className="flex space-x-4 text-sm">
            <Button
              variant={sortBy === 'rating' ? "default" : "ghost"}
              size="sm"
              className="rounded-full"
              onClick={() => setSortBy('rating')}
            >
              평점순 <i className="fas fa-chevron-down ml-1"></i>
            </Button>
            <Button
              variant={sortBy === 'reviews' ? "default" : "ghost"}
              size="sm"
              className="rounded-full"
              onClick={() => setSortBy('reviews')}
            >
              후기순 <i className="fas fa-chevron-down ml-1"></i>
            </Button>
            <Button
              variant={sortBy === 'experience' ? "default" : "ghost"}
              size="sm"
              className="rounded-full"
              onClick={() => setSortBy('experience')}
            >
              경력순 <i className="fas fa-chevron-down ml-1"></i>
            </Button>
            <Button
              variant={sortBy === 'price' ? "default" : "ghost"}
              size="sm"
              className="rounded-full"
              onClick={() => setSortBy('price')}
            >
              요금순 <i className="fas fa-chevron-down ml-1"></i>
            </Button>
          </div>
        </div>
      </div>

      {/* Search Results */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              총 <span className="font-semibold text-purple-600">{sortedManagers.length}</span>명의 케어 매니저
            </span>
            {selectedService && (
              <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                {selectedService}
              </Badge>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="p-2 rounded-lg">
              <i className="fas fa-th-large"></i>
            </Button>
            <Button variant="ghost" size="sm" className="p-2 rounded-lg">
              <i className="fas fa-list"></i>
            </Button>
          </div>
        </div>

        {sortedManagers.length === 0 ? (
          <div className="text-center py-20">
            <i className="fas fa-search text-gray-300 text-6xl mb-4"></i>
            <h3 className="text-xl font-semibold text-gray-500 mb-2">검색 결과가 없습니다</h3>
            <p className="text-gray-400">다른 키워드로 검색해보세요</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {sortedManagers.map((manager) => (
              <CareManagerCard
                key={manager.id}
                manager={manager}
                onMessage={() => handleMessageClick(manager)}
                onBook={() => handleBookingClick(manager)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Search;
