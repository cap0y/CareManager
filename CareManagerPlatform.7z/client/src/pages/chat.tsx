import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { mockMessages, mockChatMessages } from "@/lib/mock-data";

const Chat = () => {
  const { user, setShowAuthModal } = useAuth();
  const [selectedChat, setSelectedChat] = useState(0);
  const [message, setMessage] = useState("");
  const [chatMessages, setChatMessages] = useState(mockChatMessages);

  if (!user) {
    setShowAuthModal(true);
    return null;
  }

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage = {
        id: chatMessages.length + 1,
        content: message,
        sender: "user",
        timestamp: new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages([...chatMessages, newMessage]);
      setMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-20">
      {/* Header */}
      <div className="bg-white/90 backdrop-blur-sm shadow-sm px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">채팅</h1>
          <p className="text-gray-600">케어 매니저와 실시간으로 소통하세요</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Chat List */}
          <div className="lg:col-span-1">
            <Card className="bg-white/90 backdrop-blur-sm shadow-lg">
              <CardHeader className="pb-3">
                <h3 className="text-lg font-semibold text-gray-800">메시지</h3>
              </CardHeader>
              <CardContent className="p-0">
                <div className="space-y-1">
                  {mockMessages.map((chat, index) => (
                    <div
                      key={chat.id}
                      className={`p-4 cursor-pointer transition-all duration-200 ${
                        selectedChat === index 
                          ? 'bg-purple-50 border-r-4 border-purple-500' 
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedChat(index)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={chat.senderImage} />
                            <AvatarFallback>{chat.senderName[0]}</AvatarFallback>
                          </Avatar>
                          {chat.unread > 0 && (
                            <Badge className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                              {chat.unread}
                            </Badge>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <h4 className="font-semibold text-gray-800 truncate">{chat.senderName}</h4>
                            <span className="text-xs text-gray-500">{chat.timestamp}</span>
                          </div>
                          <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Window */}
          <div className="lg:col-span-2">
            <Card className="bg-white/90 backdrop-blur-sm shadow-lg h-[600px] flex flex-col">
              <CardHeader className="flex-shrink-0 pb-3 border-b border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={mockMessages[selectedChat].senderImage} />
                      <AvatarFallback>{mockMessages[selectedChat].senderName[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-semibold text-gray-800">{mockMessages[selectedChat].senderName}</h3>
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <span className="flex items-center">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                          온라인
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="p-2 rounded-lg hover:bg-purple-50"
                  >
                    <i className="fas fa-phone text-purple-600"></i>
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="flex-1 flex flex-col p-0">
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-4">
                    {chatMessages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                          msg.sender === 'user'
                            ? 'gradient-purple text-white rounded-br-sm'
                            : 'bg-gray-100 text-gray-800 rounded-bl-sm'
                        }`}>
                          <p className="text-sm">{msg.content}</p>
                          <span className={`text-xs mt-1 block ${
                            msg.sender === 'user' ? 'text-purple-100' : 'text-gray-500'
                          }`}>
                            {msg.timestamp}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <div className="flex-shrink-0 p-4 border-t border-gray-100">
                  <div className="flex items-center space-x-3">
                    <div className="flex-1 relative">
                      <Input
                        placeholder="메시지를 입력하세요..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="pr-20 border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500"
                      />
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-1">
                        <Button variant="ghost" size="sm" className="p-1 rounded-lg">
                          <i className="fas fa-paperclip text-gray-400"></i>
                        </Button>
                        <Button variant="ghost" size="sm" className="p-1 rounded-lg">
                          <i className="fas fa-camera text-gray-400"></i>
                        </Button>
                      </div>
                    </div>
                    <Button
                      onClick={handleSendMessage}
                      size="sm"
                      className="gradient-purple text-white rounded-xl hover:opacity-90"
                    >
                      <i className="fas fa-paper-plane"></i>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Chat;
