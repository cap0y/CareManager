import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

const Profile = () => {
  const { user, setShowAuthModal, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  if (!user) {
    setShowAuthModal(true);
    return null;
  }

  const handleMenuClick = (action: string) => {
    switch (action) {
      case 'bookings':
        setLocation('/bookings');
        break;
      case 'payments':
        toast({
          title: "결제 내역",
          description: "결제 내역 페이지로 이동합니다.",
        });
        break;
      case 'reviews':
        toast({
          title: "내가 쓴 리뷰",
          description: "리뷰 관리 페이지로 이동합니다.",
        });
        break;
      case 'favorites':
        toast({
          title: "찜한 케어 매니저",
          description: "즐겨찾기 목록을 확인합니다.",
        });
        break;
      case 'notifications':
        toast({
          title: "알림 설정",
          description: "알림 설정 페이지로 이동합니다.",
        });
        break;
      case 'privacy':
        toast({
          title: "개인정보 보호",
          description: "개인정보 설정 페이지로 이동합니다.",
        });
        break;
      case 'support':
        toast({
          title: "고객 지원",
          description: "고객 지원 센터로 이동합니다.",
        });
        break;
      case 'logout':
        logout();
        toast({
          title: "로그아웃",
          description: "성공적으로 로그아웃되었습니다.",
        });
        setLocation('/');
        break;
      default:
        break;
    }
  };

  const handleEditProfile = () => {
    toast({
      title: "프로필 편집",
      description: "프로필 편집 기능을 준비 중입니다.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-20">
      {/* Header */}
      <div className="bg-white/90 backdrop-blur-sm shadow-sm px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">마이페이지</h1>
          <p className="text-gray-600">계정 정보와 서비스 이용 현황을 확인하세요</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Profile Section */}
        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-100 shadow-lg mb-6">
          <CardContent className="p-6">
            <div className="flex items-center space-x-6">
              <Avatar className="w-20 h-20 border-4 border-white shadow-lg">
                <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=80&h=80" />
                <AvatarFallback className="gradient-purple text-white text-2xl font-bold">
                  {user.name[0]}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-800 mb-1">{user.name}</h2>
                <p className="text-gray-600 mb-1">{user.email}</p>
                <p className="text-gray-600">010-1234-5678</p>
              </div>
              <Button
                onClick={handleEditProfile}
                variant="outline"
                className="gradient-purple text-white border-0 hover:opacity-90 transition-all duration-200 transform hover:scale-105 shadow-lg"
              >
                <i className="fas fa-edit mr-2"></i>
                편집
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Menu Items */}
        <Card className="bg-white/90 backdrop-blur-sm shadow-lg mb-6">
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100">
              <button
                onClick={() => handleMenuClick('bookings')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-calendar-alt text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">예약 내역</h3>
                    <p className="text-sm text-gray-500">케어 서비스 예약 현황 확인</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>

              <button
                onClick={() => handleMenuClick('payments')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-teal-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-credit-card text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">결제 내역</h3>
                    <p className="text-sm text-gray-500">서비스 이용 요금 및 결제 정보</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>

              <button
                onClick={() => handleMenuClick('reviews')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-star text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">내가 쓴 리뷰</h3>
                    <p className="text-sm text-gray-500">케어 매니저 리뷰 관리</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>

              <button
                onClick={() => handleMenuClick('favorites')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-red-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-heart text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">찜한 케어 매니저</h3>
                    <p className="text-sm text-gray-500">즐겨찾기한 케어 매니저 목록</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card className="bg-white/90 backdrop-blur-sm shadow-lg mb-6">
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100">
              <button
                onClick={() => handleMenuClick('notifications')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-bell text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">알림 설정</h3>
                    <p className="text-sm text-gray-500">푸시 알림 및 이메일 설정</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>

              <button
                onClick={() => handleMenuClick('privacy')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-cyan-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-shield-alt text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">개인정보 보호</h3>
                    <p className="text-sm text-gray-500">개인정보 처리 및 보안 설정</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>

              <button
                onClick={() => handleMenuClick('support')}
                className="w-full p-6 text-left hover:bg-purple-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-question-circle text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-800">고객 지원</h3>
                    <p className="text-sm text-gray-500">FAQ, 1:1 문의 및 고객센터</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-gray-400 group-hover:text-purple-500 transition-colors duration-200"></i>
              </button>

              <button
                onClick={() => handleMenuClick('logout')}
                className="w-full p-6 text-left hover:bg-red-50 transition-all duration-200 flex items-center justify-between group"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-pink-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-200">
                    <i className="fas fa-sign-out-alt text-white text-lg"></i>
                  </div>
                  <div>
                    <h3 className="font-semibold text-red-600">로그아웃</h3>
                    <p className="text-sm text-red-400">계정에서 안전하게 로그아웃</p>
                  </div>
                </div>
                <i className="fas fa-chevron-right text-red-400 group-hover:text-red-500 transition-colors duration-200"></i>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Statistics */}
        <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-100 shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-6">이용 통계</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <Card className="bg-gradient-to-br from-blue-500 to-cyan-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-white mb-2">12</div>
                    <div className="text-blue-100 font-medium">총 예약 횟수</div>
                  </CardContent>
                </Card>
              </div>
              <div className="text-center">
                <Card className="bg-gradient-to-br from-green-500 to-teal-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-white mb-2">36시간</div>
                    <div className="text-green-100 font-medium">총 서비스 시간</div>
                  </CardContent>
                </Card>
              </div>
              <div className="text-center">
                <Card className="bg-gradient-to-br from-purple-500 to-pink-500 border-0 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  <CardContent className="p-6">
                    <div className="text-3xl font-bold text-white mb-2">4.8</div>
                    <div className="text-purple-100 font-medium">평균 만족도</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Profile;
