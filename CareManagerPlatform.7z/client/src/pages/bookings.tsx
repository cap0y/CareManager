import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { mockBookings } from "@/lib/mock-data";

const Bookings = () => {
  const { user, setShowAuthModal } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  if (!user) {
    setShowAuthModal(true);
    return null;
  }

  const handleChatClick = () => {
    setLocation('/chat');
  };

  const handleCallClick = () => {
    toast({
      title: "전화 연결",
      description: "케어 매니저와 전화를 연결하시겠습니까?",
    });
  };

  const handleLocationClick = () => {
    toast({
      title: "실시간 위치",
      description: "케어 매니저의 실시간 위치를 확인합니다.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-20">
      {/* Header */}
      <div className="bg-white/90 backdrop-blur-sm shadow-sm px-4 py-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold text-gray-800 mb-2">예약 현황</h1>
          <p className="text-gray-600">케어 서비스 예약 현황을 확인하세요</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white/90 backdrop-blur-sm rounded-xl p-1">
            <TabsTrigger value="upcoming" className="rounded-lg">예정된 예약</TabsTrigger>
            <TabsTrigger value="ongoing" className="rounded-lg">진행 중</TabsTrigger>
            <TabsTrigger value="completed" className="rounded-lg">완료된 예약</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="mt-6">
            <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-100 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                    <AvatarImage src={mockBookings[0].careManagerImage} />
                    <AvatarFallback>김</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xl font-bold text-gray-800">{mockBookings[0].careManagerName}</h3>
                      <Badge className="bg-blue-100 text-blue-700 border-blue-200">예약 확정</Badge>
                    </div>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center">
                        <i className="fas fa-calendar mr-3 w-4 text-blue-500"></i>
                        <span>{mockBookings[0].date} {mockBookings[0].time}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-hospital mr-3 w-4 text-blue-500"></i>
                        <span>{mockBookings[0].service}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-map-marker-alt mr-3 w-4 text-blue-500"></i>
                        <span>{mockBookings[0].location}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-2xl font-bold text-blue-600">{mockBookings[0].amount.toLocaleString()}원</span>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="rounded-lg border-blue-200 text-blue-600 hover:bg-blue-50"
                          onClick={handleChatClick}
                        >
                          <i className="fas fa-comment mr-2"></i>
                          채팅
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="rounded-lg border-blue-200 text-blue-600 hover:bg-blue-50"
                          onClick={handleCallClick}
                        >
                          <i className="fas fa-phone mr-2"></i>
                          통화
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ongoing" className="mt-6">
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-100 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                    <AvatarImage src={mockBookings[1].careManagerImage} />
                    <AvatarFallback>박</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xl font-bold text-gray-800">{mockBookings[1].careManagerName}</h3>
                      <Badge className="bg-green-100 text-green-700 border-green-200">서비스 진행 중</Badge>
                    </div>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center">
                        <i className="fas fa-clock mr-3 w-4 text-green-500"></i>
                        <span>{mockBookings[1].time}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-home mr-3 w-4 text-green-500"></i>
                        <span>{mockBookings[1].service}</span>
                      </div>
                      <div className="flex items-center">
                        <i className="fas fa-map-marker-alt mr-3 w-4 text-green-500"></i>
                        <span>{mockBookings[1].location}</span>
                      </div>
                    </div>
                    
                    {/* Real-time Status */}
                    <div className="bg-green-100 rounded-lg p-3 mt-4 border border-green-200">
                      <div className="flex items-center text-sm text-green-700">
                        <i className="fas fa-check-circle mr-2"></i>
                        <span>부모님 댁에 도착했습니다 (15:30)</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-2xl font-bold text-green-600">{mockBookings[1].amount.toLocaleString()}원</span>
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          className="gradient-green text-white rounded-lg hover:opacity-90"
                          onClick={handleLocationClick}
                        >
                          <i className="fas fa-map mr-2"></i>
                          실시간 위치
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="rounded-lg border-green-200 text-green-600 hover:bg-green-50"
                          onClick={handleChatClick}
                        >
                          <i className="fas fa-comment mr-2"></i>
                          채팅
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <div className="space-y-4">
              {mockBookings.map((booking, index) => (
                <Card key={index} className="bg-white/90 backdrop-blur-sm border-gray-200 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Avatar className="w-16 h-16 border-2 border-white shadow-md">
                        <AvatarImage src={booking.careManagerImage} />
                        <AvatarFallback>{booking.careManagerName[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="text-xl font-bold text-gray-800">{booking.careManagerName}</h3>
                          <Badge variant="secondary" className="bg-gray-100 text-gray-600">완료</Badge>
                        </div>
                        <div className="space-y-2 text-sm text-gray-600">
                          <div className="flex items-center">
                            <i className="fas fa-calendar mr-3 w-4 text-gray-500"></i>
                            <span>2025년 7월 {15 + index}일 완료</span>
                          </div>
                          <div className="flex items-center">
                            <i className="fas fa-clock mr-3 w-4 text-gray-500"></i>
                            <span>서비스 시간: 3시간</span>
                          </div>
                          <div className="flex items-center">
                            <i className="fas fa-star mr-3 w-4 text-yellow-500"></i>
                            <span>서비스: {booking.service}</span>
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                          <span className="text-xl font-bold text-gray-600">{booking.amount.toLocaleString()}원</span>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="rounded-lg border-yellow-200 text-yellow-600 hover:bg-yellow-50"
                          >
                            <i className="fas fa-star mr-2"></i>
                            리뷰 작성
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Bookings;
