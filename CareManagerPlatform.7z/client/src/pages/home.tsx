import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/contexts/AuthContext";
import ServiceCard from "@/components/service-card";
import CareManagerCard from "@/components/care-manager-card";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import type { Service, CareManager } from "@shared/schema";

const Home = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const { user, setShowAuthModal, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: services = [] } = useQuery<Service[]>({
    queryKey: ['/api/services'],
  });

  const { data: careManagers = [] } = useQuery<CareManager[]>({
    queryKey: ['/api/care-managers'],
  });

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setLocation(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleServiceClick = (service: Service) => {
    setLocation(`/search?service=${encodeURIComponent(service.name)}`);
  };

  const handleBookingClick = (manager: CareManager) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    toast({
      title: "예약 요청",
      description: `${manager.name} 케어 매니저에게 예약을 요청하시겠습니까?`,
    });
  };

  const handleMessageClick = (manager: CareManager) => {
    if (!user) {
      setShowAuthModal(true);
      return;
    }
    setLocation('/chat');
  };

  // Close profile menu when clicking outside
  useEffect(() => {
    const handleClickOutside = () => {
      setShowProfileMenu(false);
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-20">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b border-white/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="gradient-purple p-2 rounded-xl">
                <i className="fas fa-heart text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                케어링크
              </h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <nav className="hidden md:flex space-x-6">
                <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors duration-200 font-medium">홈</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors duration-200 font-medium">케어 매니저</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors duration-200 font-medium">서비스</a>
                <a href="#" className="text-gray-700 hover:text-purple-600 transition-colors duration-200 font-medium">고객센터</a>
              </nav>
              
              <div className="flex items-center space-x-3">
                {user && (
                  <button className="p-2 text-gray-600 hover:text-purple-600 transition-colors duration-200 hidden md:block">
                    <i className="fas fa-bell text-lg"></i>
                  </button>
                )}
                
                <div className="relative">
                  {user ? (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowProfileMenu(!showProfileMenu);
                      }}
                      className="flex items-center space-x-2 gradient-purple text-white px-4 py-2 rounded-full hover:opacity-90 transition-all duration-200 transform hover:scale-105 shadow-lg"
                    >
                      <Avatar className="w-6 h-6">
                        <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=32&h=32" />
                        <AvatarFallback>{user.name[0]}</AvatarFallback>
                      </Avatar>
                      <span className="hidden md:inline">{user.name}</span>
                    </button>
                  ) : (
                    <Button
                      onClick={() => setShowAuthModal(true)}
                      className="gradient-purple text-white px-6 py-2 rounded-full hover:opacity-90 transition-all duration-200 transform hover:scale-105 shadow-lg"
                    >
                      로그인
                    </Button>
                  )}
                  
                  {showProfileMenu && user && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-gray-100 z-50 animate-scale-in">
                      <div className="p-4 border-b border-gray-100 bg-gradient-to-r from-purple-50 to-pink-50 rounded-t-2xl">
                        <div className="flex items-center space-x-3">
                          <Avatar className="w-12 h-12">
                            <AvatarImage src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=48&h=48" />
                            <AvatarFallback className="gradient-purple text-white font-bold">{user.name[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-semibold text-gray-800">{user.name}</p>
                            <p className="text-sm text-gray-500">{user.email}</p>
                          </div>
                        </div>
                      </div>
                      <div className="p-2">
                        <button
                          onClick={() => setLocation('/profile')}
                          className="w-full text-left px-4 py-3 text-gray-700 hover:bg-purple-50 rounded-lg transition-colors duration-200 flex items-center space-x-3"
                        >
                          <i className="fas fa-user text-purple-500"></i>
                          <span>회원 정보</span>
                        </button>
                        <button
                          onClick={() => setLocation('/bookings')}
                          className="w-full text-left px-4 py-3 text-gray-700 hover:bg-purple-50 rounded-lg transition-colors duration-200 flex items-center space-x-3"
                        >
                          <i className="fas fa-calendar text-purple-500"></i>
                          <span>예약 현황</span>
                        </button>
                        <button className="w-full text-left px-4 py-3 text-gray-700 hover:bg-purple-50 rounded-lg transition-colors duration-200 flex items-center space-x-3">
                          <i className="fas fa-heart text-purple-500"></i>
                          <span>즐겨찾기</span>
                        </button>
                        <hr className="my-2 border-gray-100" />
                        <button
                          onClick={logout}
                          className="w-full text-left px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200 flex items-center space-x-3"
                        >
                          <i className="fas fa-sign-out-alt"></i>
                          <span>로그아웃</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-hero"></div>
        <div className="absolute inset-0 bg-black/20"></div>
        
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full blur-xl animate-float"></div>
        <div className="absolute bottom-10 right-10 w-32 h-32 bg-pink-500/20 rounded-full blur-2xl animate-float" style={{animationDelay: '1s'}}></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 animate-fade-in">
              부모님을 위한<br />
              <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                믿을 수 있는 케어 서비스
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-3xl mx-auto animate-fade-in" style={{animationDelay: '0.2s'}}>
              전문 케어 매니저가 부모님의 일상을 안전하고 따뜻하게 돌봐드립니다
            </p>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-8 animate-fade-in" style={{animationDelay: '0.4s'}}>
              <div className="relative">
                <Input
                  type="text"
                  placeholder="지역, 서비스명으로 검색해보세요"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="w-full px-6 py-4 pl-14 text-lg bg-white/95 backdrop-blur-sm rounded-2xl border-0 shadow-2xl focus:outline-none focus:ring-4 focus:ring-purple-300/50"
                />
                <i className="fas fa-search absolute left-5 top-1/2 transform -translate-y-1/2 text-gray-400 text-xl"></i>
                <Button
                  onClick={handleSearch}
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 gradient-purple text-white px-8 py-3 rounded-xl hover:opacity-90 transition-all duration-200 transform hover:scale-105 shadow-lg"
                >
                  검색
                </Button>
              </div>
            </div>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in" style={{animationDelay: '0.6s'}}>
              <Button
                onClick={() => setLocation('/search')}
                className="gradient-orange text-white px-8 py-4 rounded-2xl hover:opacity-90 transition-all duration-200 transform hover:scale-105 shadow-xl text-lg font-semibold"
              >
                <i className="fas fa-calendar-plus mr-2"></i>
                지금 예약하기
              </Button>
              <Button
                variant="outline"
                className="bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-8 py-4 rounded-2xl hover:bg-white/30 transition-all duration-200 transform hover:scale-105 text-lg font-semibold"
              >
                <i className="fas fa-play-circle mr-2"></i>
                서비스 소개 영상
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                서비스 카테고리
              </span>
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              다양한 케어 서비스를 통해 부모님의 건강하고 행복한 일상을 지원합니다
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service) => (
              <ServiceCard
                key={service.id}
                service={service}
                onClick={() => handleServiceClick(service)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Recommended Care Managers */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
                <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  추천 케어 매니저
                </span>
              </h2>
              <p className="text-lg text-gray-600">검증된 전문 케어 매니저들을 만나보세요</p>
            </div>
            <Button
              onClick={() => setLocation('/search')}
              className="gradient-purple text-white px-6 py-3 rounded-xl hover:opacity-90 transition-all duration-200 transform hover:scale-105 shadow-lg"
            >
              전체보기 <i className="fas fa-chevron-right ml-2"></i>
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {careManagers.map((manager) => (
              <CareManagerCard
                key={manager.id}
                manager={manager}
                onMessage={() => handleMessageClick(manager)}
                onBook={() => handleBookingClick(manager)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Real-time Popular Care Managers */}
      <section className="py-20 bg-gradient-to-br from-orange-50 to-red-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
                실시간 인기 케어 매니저
              </span>
            </h2>
            <p className="text-lg text-gray-600">지금 가장 많은 사랑을 받고 있는 케어 매니저들입니다</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {careManagers.slice(0, 2).map((manager, index) => (
              <Card key={manager.id} className="bg-white hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-orange-100">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-2xl font-bold text-xl shadow-lg">
                      {index + 1}
                    </div>
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={manager.imageUrl} alt={manager.name} />
                      <AvatarFallback>{manager.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h4 className="text-xl font-bold text-gray-800">{manager.name}</h4>
                        <span className="bg-gradient-to-r from-red-500 to-orange-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">
                          HOT
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-gray-600 mb-2">
                        <i className="fas fa-star text-yellow-400 mr-1"></i>
                        <span className="font-semibold">{manager.rating / 10}</span>
                        <span className="ml-1">({manager.reviews})</span>
                        <span className="ml-3 text-red-500 font-semibold">오늘 {Math.floor(Math.random() * 5) + 3}건 예약</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-red-600">{manager.hourlyRate.toLocaleString()}원</div>
                      <div className="text-sm text-gray-500">시간당</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 gradient-stats">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              믿을 수 있는 케어 서비스
            </h2>
            <p className="text-lg text-white/90 max-w-2xl mx-auto">
              많은 가족들이 선택하고 신뢰하는 케어링크의 서비스 현황입니다
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { number: "1,500+", label: "등록된 케어 매니저" },
              { number: "25,000+", label: "완료된 케어 서비스" },
              { number: "98%", label: "고객 만족도" },
              { number: "4.8", label: "평균 서비스 평점" }
            ].map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 hover:bg-white/30 transition-all duration-300 transform hover:scale-105">
                  <div className="text-4xl font-bold text-white mb-2">{stat.number}</div>
                  <div className="text-white/90">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="gradient-purple p-2 rounded-xl">
                  <i className="fas fa-heart text-white text-xl"></i>
                </div>
                <h3 className="text-2xl font-bold">케어링크</h3>
              </div>
              <p className="text-gray-400 mb-4">
                부모님을 위한 믿을 수 있는 케어 서비스 플랫폼
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                  <i className="fab fa-facebook-f"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                  <i className="fab fa-instagram"></i>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                  <i className="fab fa-youtube"></i>
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">서비스</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors duration-200">병원 동행</a></li>
                <li><a href="#" className="hover:text-white transition-colors duration-200">장보기</a></li>
                <li><a href="#" className="hover:text-white transition-colors duration-200">가사 도움</a></li>
                <li><a href="#" className="hover:text-white transition-colors duration-200">말벗</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">고객센터</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors duration-200">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition-colors duration-200">1:1 문의</a></li>
                <li><a href="#" className="hover:text-white transition-colors duration-200">공지사항</a></li>
                <li><a href="#" className="hover:text-white transition-colors duration-200">이용약관</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">연락처</h4>
              <div className="text-gray-400 space-y-2">
                <p><i className="fas fa-phone mr-2"></i> 1588-0000</p>
                <p><i className="fas fa-envelope mr-2"></i> info@carelink.co.kr</p>
                <p><i className="fas fa-map-marker-alt mr-2"></i> 서울시 강남구 테헤란로 123</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 케어링크. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
