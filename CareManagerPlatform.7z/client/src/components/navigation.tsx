import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";

const Navigation = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [location, setLocation] = useLocation();
  const { user, setShowAuthModal } = useAuth();

  useEffect(() => {
    const path = location.split('/')[1] || 'home';
    setActiveTab(path);
  }, [location]);

  const handleTabClick = (tabId: string) => {
    if (!user && (tabId === 'bookings' || tabId === 'chat' || tabId === 'profile')) {
      setShowAuthModal(true);
      return;
    }
    
    setActiveTab(tabId);
    const path = tabId === 'home' ? '/' : `/${tabId}`;
    setLocation(path);
  };

  const tabs = [
    { id: 'home', icon: 'fas fa-home', label: '홈', path: '/' },
    { id: 'search', icon: 'fas fa-search', label: '검색', path: '/search' },
    { id: 'bookings', icon: 'fas fa-calendar', label: '예약현황', path: '/bookings' },
    { id: 'chat', icon: 'fas fa-comment', label: '채팅', path: '/chat' },
    { id: 'profile', icon: 'fas fa-user', label: '마이페이지', path: '/profile' }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40">
      <div className="bg-white/90 backdrop-blur-sm border-t border-gray-200 px-4 py-2 shadow-lg">
        <div className="flex justify-around max-w-md mx-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`flex flex-col items-center py-2 px-3 rounded-lg transition-all duration-200 ${
                activeTab === tab.id 
                  ? 'text-purple-600 bg-purple-50 transform scale-105' 
                  : 'text-gray-500 hover:text-purple-600 hover:bg-purple-50'
              }`}
            >
              <i className={`${tab.icon} text-lg mb-1`}></i>
              <span className="text-xs font-medium">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Navigation;
