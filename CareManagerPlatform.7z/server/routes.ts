import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertBookingSchema, insertMessageSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(userData.email);
      
      if (existingUser) {
        return res.status(400).json({ error: "이미 존재하는 이메일입니다" });
      }
      
      const user = await storage.createUser(userData);
      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(400).json({ error: "회원가입에 실패했습니다" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      const user = await storage.getUserByEmail(email);
      
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "이메일 또는 비밀번호가 잘못되었습니다" });
      }
      
      res.json({ user: { id: user.id, email: user.email, name: user.name } });
    } catch (error) {
      res.status(400).json({ error: "로그인에 실패했습니다" });
    }
  });

  // Care Manager routes
  app.get("/api/care-managers", async (req, res) => {
    try {
      const careManagers = await storage.getAllCareManagers();
      res.json(careManagers);
    } catch (error) {
      res.status(500).json({ error: "케어 매니저 목록을 불러오는데 실패했습니다" });
    }
  });

  app.get("/api/care-managers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const careManager = await storage.getCareManager(id);
      
      if (!careManager) {
        return res.status(404).json({ error: "케어 매니저를 찾을 수 없습니다" });
      }
      
      res.json(careManager);
    } catch (error) {
      res.status(500).json({ error: "케어 매니저 정보를 불러오는데 실패했습니다" });
    }
  });

  // Service routes
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getAllServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ error: "서비스 목록을 불러오는데 실패했습니다" });
    }
  });

  // Booking routes
  app.post("/api/bookings", async (req, res) => {
    try {
      const bookingData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(bookingData);
      res.json(booking);
    } catch (error) {
      res.status(400).json({ error: "예약 생성에 실패했습니다" });
    }
  });

  app.get("/api/bookings/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const bookings = await storage.getBookingsByUser(userId);
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ error: "예약 목록을 불러오는데 실패했습니다" });
    }
  });

  app.put("/api/bookings/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const booking = await storage.updateBookingStatus(id, status);
      
      if (!booking) {
        return res.status(404).json({ error: "예약을 찾을 수 없습니다" });
      }
      
      res.json(booking);
    } catch (error) {
      res.status(500).json({ error: "예약 상태 업데이트에 실패했습니다" });
    }
  });

  // Message routes
  app.post("/api/messages", async (req, res) => {
    try {
      const messageData = insertMessageSchema.parse(req.body);
      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      res.status(400).json({ error: "메시지 전송에 실패했습니다" });
    }
  });

  app.get("/api/messages/:userId1/:userId2", async (req, res) => {
    try {
      const userId1 = parseInt(req.params.userId1);
      const userId2 = parseInt(req.params.userId2);
      const messages = await storage.getMessagesBetweenUsers(userId1, userId2);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "메시지 목록을 불러오는데 실패했습니다" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
