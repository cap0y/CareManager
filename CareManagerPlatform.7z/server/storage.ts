import { db } from "./db";
import { users, careManagers, services, bookings, messages, type User, type InsertUser, type CareManager, type InsertCareManager, type Service, type InsertService, type Booking, type InsertBooking, type Message, type InsertMessage } from "@shared/schema";
import { eq, and, or, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Care Manager operations
  getCareManager(id: number): Promise<CareManager | undefined>;
  getAllCareManagers(): Promise<CareManager[]>;
  getCareManagersByService(serviceId: number): Promise<CareManager[]>;
  createCareManager(careManager: InsertCareManager): Promise<CareManager>;
  
  // Service operations
  getService(id: number): Promise<Service | undefined>;
  getAllServices(): Promise<Service[]>;
  createService(service: InsertService): Promise<Service>;
  
  // Booking operations
  getBooking(id: number): Promise<Booking | undefined>;
  getBookingsByUser(userId: number): Promise<Booking[]>;
  getBookingsByCareManager(careManagerId: number): Promise<Booking[]>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  updateBookingStatus(id: number, status: string): Promise<Booking | undefined>;
  
  // Message operations
  getMessagesBetweenUsers(userId1: number, userId2: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private careManagers: Map<number, CareManager>;
  private services: Map<number, Service>;
  private bookings: Map<number, Booking>;
  private messages: Map<number, Message>;
  private currentUserId: number;
  private currentCareManagerId: number;
  private currentServiceId: number;
  private currentBookingId: number;
  private currentMessageId: number;

  constructor() {
    this.users = new Map();
    this.careManagers = new Map();
    this.services = new Map();
    this.bookings = new Map();
    this.messages = new Map();
    this.currentUserId = 1;
    this.currentCareManagerId = 1;
    this.currentServiceId = 1;
    this.currentBookingId = 1;
    this.currentMessageId = 1;
    
    this.initializeData();
  }

  private initializeData() {
    // Initialize services
    const servicesData = [
      { name: '병원 동행', icon: 'fas fa-hospital', color: 'bg-gradient-to-br from-blue-500 to-cyan-500', description: '의료진과의 소통을 도와드리고 안전한 병원 방문을 지원합니다', averageDuration: '평균 3-4시간 소요' },
      { name: '장보기', icon: 'fas fa-shopping-cart', color: 'bg-gradient-to-br from-green-500 to-teal-500', description: '신선한 식재료와 생필품을 대신 구매해드립니다', averageDuration: '평균 2-3시간 소요' },
      { name: '가사 도움', icon: 'fas fa-home', color: 'bg-gradient-to-br from-purple-500 to-pink-500', description: '청소, 세탁, 정리정돈 등 집안일을 도와드립니다', averageDuration: '평균 4-5시간 소요' },
      { name: '말벗', icon: 'fas fa-comments', color: 'bg-gradient-to-br from-orange-500 to-red-500', description: '따뜻한 대화와 정서적 지원을 제공합니다', averageDuration: '평균 2-3시간 소요' }
    ];

    servicesData.forEach(service => {
      const newService: Service = {
        id: this.currentServiceId++,
        ...service
      };
      this.services.set(newService.id, newService);
    });

    // Initialize care managers
    const careManagersData = [
      {
        name: '김미영',
        age: 45,
        rating: 49, // 4.9
        reviews: 127,
        experience: '5년',
        location: '서울 강남구',
        hourlyRate: 25000,
        services: ['병원 동행', '장보기'],
        certified: true,
        imageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120',
        description: '5년간의 경험을 바탕으로 세심하고 전문적인 케어 서비스를 제공합니다.'
      },
      {
        name: '박정수',
        age: 52,
        rating: 48, // 4.8
        reviews: 89,
        experience: '7년',
        location: '서울 송파구',
        hourlyRate: 23000,
        services: ['가사 도움', '말벗'],
        certified: true,
        imageUrl: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120',
        description: '7년의 풍부한 경험으로 어르신들께 따뜻한 돌봄을 제공합니다.'
      },
      {
        name: '이순희',
        age: 48,
        rating: 47, // 4.7
        reviews: 156,
        experience: '6년',
        location: '서울 마포구',
        hourlyRate: 24000,
        services: ['병원 동행', '말벗', '장보기'],
        certified: true,
        imageUrl: 'https://images.unsplash.com/photo-1607990281513-2c110a25bd8c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=120&h=120',
        description: '다양한 서비스 경험을 통해 개인별 맞춤 케어를 제공합니다.'
      }
    ];

    careManagersData.forEach(manager => {
      const newManager: CareManager = {
        id: this.currentCareManagerId++,
        ...manager,
        createdAt: new Date()
      };
      this.careManagers.set(newManager.id, newManager);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      id: this.currentUserId++,
      ...insertUser,
      phone: insertUser.phone || null,
      createdAt: new Date()
    };
    this.users.set(user.id, user);
    return user;
  }

  // Care Manager operations
  async getCareManager(id: number): Promise<CareManager | undefined> {
    return this.careManagers.get(id);
  }

  async getAllCareManagers(): Promise<CareManager[]> {
    return Array.from(this.careManagers.values());
  }

  async getCareManagersByService(serviceId: number): Promise<CareManager[]> {
    const service = this.services.get(serviceId);
    if (!service) return [];
    
    return Array.from(this.careManagers.values()).filter(manager => 
      (manager.services as string[]).includes(service.name)
    );
  }

  async createCareManager(insertCareManager: InsertCareManager): Promise<CareManager> {
    const careManager: CareManager = {
      id: this.currentCareManagerId++,
      ...insertCareManager,
      description: insertCareManager.description || null,
      imageUrl: insertCareManager.imageUrl || null,
      reviews: insertCareManager.reviews || 0,
      certified: insertCareManager.certified || false,
      createdAt: new Date()
    };
    this.careManagers.set(careManager.id, careManager);
    return careManager;
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async getAllServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async createService(insertService: InsertService): Promise<Service> {
    const service: Service = {
      id: this.currentServiceId++,
      ...insertService,
      description: insertService.description || null,
      averageDuration: insertService.averageDuration || null
    };
    this.services.set(service.id, service);
    return service;
  }

  // Booking operations
  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async getBookingsByUser(userId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(booking => booking.userId === userId);
  }

  async getBookingsByCareManager(careManagerId: number): Promise<Booking[]> {
    return Array.from(this.bookings.values()).filter(booking => booking.careManagerId === careManagerId);
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const booking: Booking = {
      id: this.currentBookingId++,
      ...insertBooking,
      status: insertBooking.status || "pending",
      notes: insertBooking.notes || null,
      createdAt: new Date()
    };
    this.bookings.set(booking.id, booking);
    return booking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const booking = this.bookings.get(id);
    if (!booking) return undefined;
    
    const updatedBooking = { ...booking, status };
    this.bookings.set(id, updatedBooking);
    return updatedBooking;
  }

  // Message operations
  async getMessagesBetweenUsers(userId1: number, userId2: number): Promise<Message[]> {
    return Array.from(this.messages.values()).filter(message => 
      (message.senderId === userId1 && message.receiverId === userId2) ||
      (message.senderId === userId2 && message.receiverId === userId1)
    ).sort((a, b) => (a.timestamp?.getTime() || 0) - (b.timestamp?.getTime() || 0));
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const message: Message = {
      id: this.currentMessageId++,
      ...insertMessage,
      timestamp: new Date(),
      isRead: false
    };
    this.messages.set(message.id, message);
    return message;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, isRead: true };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Care Manager operations
  async getCareManager(id: number): Promise<CareManager | undefined> {
    const [careManager] = await db.select().from(careManagers).where(eq(careManagers.id, id));
    return careManager || undefined;
  }

  async getAllCareManagers(): Promise<CareManager[]> {
    return await db.select().from(careManagers);
  }

  async getCareManagersByService(serviceId: number): Promise<CareManager[]> {
    // This would require a more complex query with JSON operations in a real implementation
    return await db.select().from(careManagers);
  }

  async createCareManager(insertCareManager: InsertCareManager): Promise<CareManager> {
    const [careManager] = await db
      .insert(careManagers)
      .values(insertCareManager)
      .returning();
    return careManager;
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db.select().from(services).where(eq(services.id, id));
    return service || undefined;
  }

  async getAllServices(): Promise<Service[]> {
    return await db.select().from(services);
  }

  async createService(insertService: InsertService): Promise<Service> {
    const [service] = await db
      .insert(services)
      .values(insertService)
      .returning();
    return service;
  }

  // Booking operations
  async getBooking(id: number): Promise<Booking | undefined> {
    const [booking] = await db.select().from(bookings).where(eq(bookings.id, id));
    return booking || undefined;
  }

  async getBookingsByUser(userId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.userId, userId));
  }

  async getBookingsByCareManager(careManagerId: number): Promise<Booking[]> {
    return await db.select().from(bookings).where(eq(bookings.careManagerId, careManagerId));
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const [booking] = await db
      .insert(bookings)
      .values(insertBooking)
      .returning();
    return booking;
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking | undefined> {
    const [booking] = await db
      .update(bookings)
      .set({ status })
      .where(eq(bookings.id, id))
      .returning();
    return booking || undefined;
  }

  // Message operations
  async getMessagesBetweenUsers(userId1: number, userId2: number): Promise<Message[]> {
    return await db.select().from(messages)
      .where(
        or(
          and(eq(messages.senderId, userId1), eq(messages.receiverId, userId2)),
          and(eq(messages.senderId, userId2), eq(messages.receiverId, userId1))
        )
      )
      .orderBy(desc(messages.timestamp));
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const [message] = await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, id))
      .returning();
    return message || undefined;
  }
}

export const storage = new DatabaseStorage();
