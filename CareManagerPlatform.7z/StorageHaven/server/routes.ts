import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertReservationSchema, insertUserSchema } from "@shared/schema";
import { z } from "zod";
import { db } from "./db";
import { storageUnits, reservations, users, storageLocations } from "@shared/schema";
import { insertStorageUnitSchema } from "@shared/schema";
import { insertStorageLocationSchema } from "@shared/schema";
import { and, gte, lte, or, eq, lt } from "drizzle-orm";

// 사용자 등록 스키마 (Firebase UID 포함)
const firebaseUserSchema = z.object({
  firebaseUid: z.string(),
  username: z.string(),
  email: z.string().email(),
  password: z.string(),
  displayName: z.string().optional(),
  photoURL: z.string().optional(),
  userType: z.enum(['user', 'franchise', 'admin']),
  isApproved: z.boolean().optional(),
  franchiseInfo: z.object({
    name: z.string(),
    address: z.string(),
    phone: z.string(),
    isApproved: z.boolean()
  }).optional()
});

export async function registerRoutes(app: Express): Promise<Server> {

  // 글로벌 미들웨어: 만료된 예약 상태 자동 업데이트
  app.use(async (_req, _res, next) => {
    try {
      // end_date 가 지난 active 예약을 expired 로 전환
      await db
        .update(reservations)
        .set({ status: 'expired' })
        .where(
          and(
            eq(reservations.status, 'active'),
            lt(reservations.endDate, new Date())
          )
        );
    } catch (e) {
      console.error('[AutoExpire] 예약 만료 처리 실패:', e);
    }
    next();
  });
  
  // Firebase UID 로 사용자 조회 - 이 라우트를 가장 먼저 정의
  app.get("/api/users/by-firebase/:uid", async (req, res) => {
    console.log(`[DEBUG] Firebase UID 조회 요청: ${req.params.uid}`);
    try {
      const uid = req.params.uid;
      // 쿼리 파라미터에서 이메일과 표시 이름 가져오기
      const email = req.query.email as string || '';
      const displayName = req.query.displayName as string || '';
      
      const user = await storage.getUserByFirebaseUid(uid);
      
      if (!user) {
        console.log(`[DEBUG] Firebase UID ${uid} 사용자 없음, 기본 사용자 생성 시도`);
        
        // 기본 사용자 생성
        try {
          // 유니크한 username 생성 (Firebase UID 기반)
          const username = email 
            ? email.split('@')[0] 
            : `user_${uid.substring(0, 8)}`;
          
          // 기본 사용자 정보로 사용자 생성
          const newUser = await storage.createUser({
            firebaseUid: uid,
            username: username,
            email: email || `${username}@example.com`, // 이메일이 제공되면 그것을 사용, 없으면 임시 이메일
            password: "firebase_auth_user", // 실제 인증은 Firebase가 담당하므로 의미 없는 값
            displayName: displayName || username, // 표시 이름이 제공되면 그것을 사용, 없으면 사용자명
            userType: 'user', // 기본 타입은 일반 사용자
            isApproved: true // 일반 사용자는 승인 필요 없음
          });
          
          console.log(`[DEBUG] Firebase UID ${uid} 사용자 자동 생성 성공:`, newUser);
          return res.json({ success: true, user: newUser });
        } catch (createError: any) {
          console.error(`[ERROR] Firebase UID ${uid} 사용자 자동 생성 실패:`, createError);
          return res.status(500).json({ 
            success: false, 
            message: "Failed to auto-create user", 
            error: createError.message 
          });
        }
      }
      
      console.log(`[DEBUG] Firebase UID ${uid} 사용자 조회 성공:`, user);
      res.json({ success: true, user });
    } catch (error: any) {
      console.error(`[ERROR] Firebase UID ${req.params.uid} 조회 오류:`, error);
      res.status(500).json({ success: false, message: "Error fetching user: " + error.message });
    }
  });
  
  // 사용자 API - 가맹점 사업주 및 관리자용
  app.post("/api/users", async (req, res) => {
    try {
      const userData = firebaseUserSchema.parse(req.body);
      
      // Firebase UID로 사용자 조회
      const existingUser = await storage.getUserByFirebaseUid(userData.firebaseUid).catch(() => null);
      
      // 이미 존재하면 업데이트
      if (existingUser) {
        res.json({
          success: true,
          message: "User already exists",
          user: existingUser
        });
        return;
      }
      
      // 사용자 생성
      const user = await storage.createUser({
        firebaseUid: userData.firebaseUid,
        username: userData.username,
        email: userData.email,
        password: userData.password, // 실제론 Firebase가 인증 관리
        displayName: userData.displayName,
        photoURL: userData.photoURL,
        userType: userData.userType,
        isApproved: userData.isApproved || false,
        franchiseInfo: userData.franchiseInfo
      });
      
      res.status(201).json({
        success: true,
        message: "User created successfully",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          userType: user.userType,
          isApproved: user.isApproved
        }
      });
    } catch (error: any) {
      console.error("사용자 생성 오류:", error);
      res.status(400).json({ success: false, message: "Error creating user: " + error.message });
    }
  });
  
  // 가맹점 사업주 승인 API
  app.patch("/api/users/:userId/approve", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.updateUserApprovalStatus(userId, true);
      
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }
      
      res.json({
        success: true,
        message: "User approved successfully",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          userType: user.userType,
          isApproved: user.isApproved
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, message: "Error approving user: " + error.message });
    }
  });
  
  // 가맹점 사업주 승인 거부 API
  app.patch("/api/users/:userId/reject", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.updateUserApprovalStatus(userId, false);
      
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }
      
      res.json({
        success: true,
        message: "User approval rejected",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          userType: user.userType,
          isApproved: user.isApproved
        }
      });
    } catch (error: any) {
      res.status(500).json({ success: false, message: "Error rejecting user approval: " + error.message });
    }
  });

  // 슈퍼유저 권한 부여/해제 API
  app.patch("/api/users/:userId/superuser", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { isSuperUser } = req.body as { isSuperUser: boolean };
      const user = await storage.updateUserSuperUserStatus(userId, Boolean(isSuperUser));

      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }

      res.json({ success: true, user });
    } catch (error: any) {
      res.status(500).json({ success: false, message: "Error updating superuser status: " + error.message });
    }
  });

  // 파트너 ID 업데이트
  app.patch("/api/users/:userId/partner", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { partnerId } = req.body as { partnerId: string };
      
      const user = await storage.updatePartnerId(userId, partnerId);
      
      if (!user) {
        return res.status(404).json({ success: false, message: "User not found" });
      }
      
      res.json({ 
        success: true, 
        message: "Partner ID updated successfully", 
        user 
      });
    } catch (error: any) {
      res.status(500).json({ success: false, message: "Error updating partner ID: " + error.message });
    }
  });

  // 승인된 가맹점 목록
  app.get("/api/admin/franchises", async (_req, res) => {
    try {
      const franchises = await storage.getApprovedFranchises();
      res.json({ success: true, franchises });
    } catch (error: any) {
      res.status(500).json({ success: false, message: "Error fetching franchises: " + error.message });
    }
  });
  
  // 승인 대기중인 가맹점 사업주 목록 조회 API
  app.get("/api/users/pending-franchises", async (req, res) => {
    try {
      // PostgreSQL에서 승인 대기 중인 가맹점 사업주 조회
      const pendingFranchises = await storage.getFranchisePendingApprovals();
      
      res.json({
        success: true,
        pendingFranchises: pendingFranchises.map(franchise => ({
          id: franchise.id,
          username: franchise.username,
          email: franchise.email,
          displayName: franchise.displayName,
          userType: franchise.userType,
          isApproved: franchise.isApproved,
          franchiseInfo: franchise.franchiseInfo,
          createdAt: franchise.createdAt
        }))
      });
    } catch (error: any) {
      res.status(500).json({ success: false, message: "Error fetching pending franchises: " + error.message });
    }
  });
  
  // Storage locations
  app.get("/api/storage-locations", async (req, res) => {
    try {
      const locations = await storage.getStorageLocations();
      res.json(locations);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching storage locations: " + error.message });
    }
  });

  app.get("/api/storage-locations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const location = await storage.getStorageLocation(id);
      if (!location) {
        return res.status(404).json({ message: "Storage location not found" });
      }
      res.json(location);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching storage location: " + error.message });
    }
  });

  // 특정 소유자(firebaseUid)의 창고 목록
  app.get("/api/users/:firebaseUid/storage-locations", async (req, res) => {
    try {
      const firebaseUid = req.params.firebaseUid;
      const owner = await storage.getUserByFirebaseUid(firebaseUid);
      if (!owner) return res.json([]);
      const locations = await storage.getStorageLocationsByOwnerId(owner.id);
      res.json(locations);
    } catch (e: any) {
      res.status(500).json({ message: "Error fetching owner locations: " + e.message });
    }
  });

  // Create new storage location
  app.post("/api/storage-locations", async (req, res) => {
    try {
      // ownerId 는 인증 정보에서 추출하거나 프론트엔드에서 전달
      const raw = {
        ...req.body,
        latitude: req.body.latitude ? String(req.body.latitude) : undefined,
        longitude: req.body.longitude ? String(req.body.longitude) : undefined,
      };
      const locationData = insertStorageLocationSchema.parse(raw);
      const location = await storage.createStorageLocation(locationData);
      res.status(201).json(location);
    } catch (error: any) {
      res.status(400).json({ message: "Error creating storage location: " + error.message });
    }
  });

  // Storage units
  app.get("/api/storage-locations/:locationId/units", async (req, res) => {
    try {
      const locationId = parseInt(req.params.locationId);
      const units = await storage.getStorageUnits(locationId);
      res.json(units);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching storage units: " + error.message });
    }
  });

  app.get("/api/storage-locations/:locationId/available-units", async (req, res) => {
    try {
      const locationId = parseInt(req.params.locationId);
      const units = await storage.getAvailableStorageUnits(locationId);
      res.json(units);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching available storage units: " + error.message });
    }
  });

  app.get("/api/storage-locations/:locationId/reserved-units", async (req, res) => {
    try {
      const locationId = parseInt(req.params.locationId);
      if (isNaN(locationId)) return res.status(400).json({ message: "Invalid locationId" });

      const rows = await db
        .select({
          unitId: reservations.storageUnitId,
          startDate: reservations.startDate,
          endDate: reservations.endDate,
        })
        .from(reservations)
        .leftJoin(storageUnits, eq(storageUnits.id, reservations.storageUnitId))
        .where(
          and(
            eq(storageUnits.locationId, locationId),
            or(eq(reservations.status, 'pending'), eq(reservations.status, 'active'))
          )
        );
      res.json(rows);
    } catch (e:any) {
      res.status(500).json({ message: "Error fetching reserved units: " + e.message });
    }
  });

  app.get("/api/storage-units/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const unit = await storage.getStorageUnit(id);
      if (!unit) {
        return res.status(404).json({ message: "Storage unit not found" });
      }
      res.json(unit);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching storage unit: " + error.message });
    }
  });

  // Create storage unit
  app.post("/api/storage-locations/:locationId/units", async (req, res) => {
    try {
      const locationId = parseInt(req.params.locationId);
      const body = req.body;
      const unitDataRaw = {
        ...body,
        locationId,
        dailyPrice: String(body.dailyPrice),
        monthlyPrice: String(body.monthlyPrice),
        quarterlyPrice: String(body.quarterlyPrice),
        yearlyPrice: String(body.yearlyPrice),
      };
      const unitData = insertStorageUnitSchema.parse(unitDataRaw);
      const unit = await storage.createStorageUnit(unitData);
      res.status(201).json(unit);
    } catch (e: any) {
      res.status(400).json({ message: "Error creating storage unit: " + e.message });
    }
  });

  // User registration
  app.post("/api/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json({ success: true, user: { id: user.id, username: user.username, email: user.email } });
    } catch (error: any) {
      res.status(400).json({ message: "Error creating user: " + error.message });
    }
  });

  // Create reservation
  app.post("/api/reservations", async (req, res) => {
    try {
      // 디버깅: 요청 데이터 출력
      console.log("예약 생성 요청 데이터:", req.body);
      
      // 스키마 유효성 검사
      try {
        const reservationData = insertReservationSchema.parse(req.body);
        console.log("파싱된 예약 데이터:", reservationData);
        
        const reservation = await storage.createReservation(reservationData);
        console.log("생성된 예약:", reservation);
        
        res.json(reservation);
      } catch (parseError: any) {
        console.error("예약 데이터 파싱 오류:", parseError);
        res.status(400).json({ 
          message: "예약 데이터 유효성 검사 실패", 
          errors: parseError.errors || parseError.message 
        });
      }
    } catch (error: any) {
      console.error("예약 생성 오류:", error);
      res.status(400).json({ message: "Error creating reservation: " + error.message });
    }
  });

  // Get user reservations
  app.get("/api/users/:userId/reservations", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const reservations = await storage.getReservations(userId);
      res.json(reservations);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching reservations: " + error.message });
    }
  });

  // [ADMIN] 전체 예약 목록 (사용자·보관함 조인)
  app.get("/api/admin/reservations", async (_req, res) => {
    try {
      res.set("Cache-Control", "no-store");
      const results = await db
        .select({
          reservationId: reservations.id,
          status: reservations.status,
          startDate: reservations.startDate,
          endDate: reservations.endDate,
          totalAmount: reservations.totalAmount,
          userName: users.displayName,
          userEmail: users.email,
          userPhone: users.phone,
          unitNumber: storageUnits.unitNumber,
        })
        .from(reservations)
        .leftJoin(users, eq(users.id, reservations.userId))
        .leftJoin(storageUnits, eq(storageUnits.id, reservations.storageUnitId));

      res.json({ success: true, reservations: results });
    } catch (e: any) {
      console.error("[ADMIN] 예약 목록 조회 오류:", e);
      res.status(500).json({ success: false, message: e.message });
    }
  });

  // [ADMIN] 예약 상태 변경
  app.patch("/api/admin/reservations/:id/status", async (req, res) => {
    try {
      const reservationId = parseInt(req.params.id);
      const { status } = req.body as { status: string };

      // 유효한 상태 값인지 검증
      const allowed = ["pending", "active", "expired", "cancelled"] as const;
      if (!allowed.includes(status as any)) {
        return res.status(400).json({ success: false, message: "Invalid status" });
      }

      // 상태 업데이트
      await db
        .update(reservations)
        .set({ status })
        .where(eq(reservations.id, reservationId));

      // 갱신된 전체 목록 반환 (프론트에서 새로 고침 필요 없이 받을 수 있도록)
      const results = await db
        .select({
          reservationId: reservations.id,
          status: reservations.status,
          startDate: reservations.startDate,
          endDate: reservations.endDate,
          totalAmount: reservations.totalAmount,
          userName: users.displayName,
          userEmail: users.email,
          userPhone: users.phone,
          unitNumber: storageUnits.unitNumber,
        })
        .from(reservations)
        .leftJoin(users, eq(users.id, reservations.userId))
        .leftJoin(storageUnits, eq(storageUnits.id, reservations.storageUnitId));

      res.json({ success: true, reservations: results });
    } catch (e: any) {
      console.error("[ADMIN] 예약 상태 변경 오류:", e);
      res.status(500).json({ success: false, message: e.message });
    }
  });

  // [FRANCHISE] 특정 가맹점(소유자) 예약 목록
  app.get("/api/franchises/:ownerId/reservations", async (req, res) => {
    try {
      const ownerId = parseInt(req.params.ownerId);
      if (isNaN(ownerId)) return res.status(400).json({ success:false, message:"Invalid ownerId" });

      const results = await db
        .select({
          reservationId: reservations.id,
          status: reservations.status,
          startDate: reservations.startDate,
          endDate: reservations.endDate,
          totalAmount: reservations.totalAmount,
          userName: users.displayName,
          userEmail: users.email,
          userPhone: users.phone,
          unitNumber: storageUnits.unitNumber,
        })
        .from(reservations)
        .leftJoin(users, eq(users.id, reservations.userId))
        .leftJoin(storageUnits, eq(storageUnits.id, reservations.storageUnitId))
        .leftJoin(storageLocations, eq(storageLocations.id, storageUnits.locationId))
        .where(eq(storageLocations.ownerId, ownerId));

      res.json({ success:true, reservations: results });
    } catch (e:any) {
      console.error("[FRANCHISE] 예약 목록 조회 오류:", e);
      res.status(500).json({ success:false, message:e.message });
    }
  });

  // [FRANCHISE] 예약 상태 변경 (가맹점 소유자 전용)
  app.patch("/api/franchises/:ownerId/reservations/:id/status", async (req, res) => {
    try {
      const ownerId = parseInt(req.params.ownerId);
      const reservationId = parseInt(req.params.id);
      const { status } = req.body as { status: string };
      const allowed = ["pending","active","expired","cancelled"] as const;
      if (!allowed.includes(status as any)) return res.status(400).json({ success:false, message:"Invalid status" });

      // 예약이 해당 owner의 보관함에 속하는지 확인
      const [row] = await db
        .select({ id: reservations.id })
        .from(reservations)
        .leftJoin(storageUnits, eq(storageUnits.id, reservations.storageUnitId))
        .leftJoin(storageLocations, eq(storageLocations.id, storageUnits.locationId))
        .where(and(eq(reservations.id, reservationId), eq(storageLocations.ownerId, ownerId)));

      if (!row) return res.status(404).json({ success:false, message:"Reservation not found or not owned" });

      await db.update(reservations).set({ status }).where(eq(reservations.id, reservationId));

      // 변경 후 최신 목록 반환
      const results = await db
        .select({
          reservationId: reservations.id,
          status: reservations.status,
          startDate: reservations.startDate,
          endDate: reservations.endDate,
          totalAmount: reservations.totalAmount,
          userName: users.displayName,
          userEmail: users.email,
          userPhone: users.phone,
          unitNumber: storageUnits.unitNumber,
        })
        .from(reservations)
        .leftJoin(users, eq(users.id, reservations.userId))
        .leftJoin(storageUnits, eq(storageUnits.id, reservations.storageUnitId))
        .leftJoin(storageLocations, eq(storageLocations.id, storageUnits.locationId))
        .where(eq(storageLocations.ownerId, ownerId));

      res.json({ success:true, reservations: results });
    } catch (e:any) {
      console.error("[FRANCHISE] 예약 상태 변경 오류:", e);
      res.status(500).json({ success:false, message:e.message });
    }
  });

  // PortOne payment endpoint
  app.post("/api/create-payment", async (req, res) => {
    try {
      const { amount, orderName, unitId, customerEmail, customerName, startDate, endDate, period } = req.body;

      if (!startDate || !endDate) {
        return res.status(400).json({ success:false, message: "startDate, endDate가 필요합니다." });
      }

      const start = new Date(startDate);
      const end = new Date(endDate);

      // 1) 중복 예약 체크 (pending 또는 active)
      const overlap = await db
        .select()
        .from(reservations)
        .where(
          and(
            eq(reservations.storageUnitId, unitId),
            or(
              and(lte(reservations.startDate, end), gte(reservations.endDate, start)),
              and(lte(reservations.startDate, start), gte(reservations.endDate, start))
            ),
            or(eq(reservations.status, 'pending'), eq(reservations.status, 'active'))
          )
        );

      if (overlap.length > 0) {
        return res.json({ success:false, message:"이미 예약된 기간입니다." });
      }

      // 2) 사용자 확인 또는 생성
      let user = await db
        .select()
        .from(users)
        .where(eq(users.email, customerEmail))
        .limit(1);

      if (user.length === 0) {
        // 새 사용자 생성
        const newUserData = insertUserSchema.parse({
          username: customerName || `user_${Date.now()}`,
          email: customerEmail,
          password: 'temp_password', // 임시 비밀번호
          displayName: customerName,
          userType: 'user',
          phone: '010-0000-0000', // 임시 전화번호
          isApproved: true,
          firebaseUid: `temp_uid_${Date.now()}`,
        });

        const [newUser] = await db.insert(users).values(newUserData).returning();
        user = [newUser];
      }

      // 3) 예약 레코드 생성 (pending)
      const reservationData = insertReservationSchema.parse({
        userId: user[0].id,
        storageUnitId: unitId,
        subscriptionType: period || 'daily',
        startDate: start,
        endDate: end,
        totalAmount: amount,
      });

      const [reservation] = await db.insert(reservations).values(reservationData).returning();
 
      // Generate unique order ID
      const orderId = `ORDER_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      // Store payment information for verification
      const paymentInfo = {
        orderId,
        amount,
        orderName,
        unitId,
        customerEmail,
        customerName,
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      
      // In production, you would store this in database
      // For now, we'll just return the payment info
      res.json({
        orderId,
        amount,
        orderName,
        customerEmail,
        customerName,
        reservationId: reservation.id,
        success: true
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment: " + error.message });
    }
  });

  // Payment verification endpoint
  app.post("/api/verify-payment", async (req, res) => {
    try {
      const { orderId, paymentId, amount } = req.body;
      
      // In production, you would verify with PortOne API
      // For now, we'll simulate successful verification
      res.json({
        success: true,
        orderId,
        paymentId,
        amount,
        status: 'verified'
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error verifying payment: " + error.message });
    }
  });

  // Seed data endpoint for development
  app.post("/api/seed-data", async (req, res) => {
    try {
      // Create sample storage locations
      const locations = [
        {
          name: "마곡 강서구 공유창고",
          address: "서울특별시 강서구 마곡동로 137호 1층",
          city: "서울특별시",
          district: "강서구",
          latitude: "37.5665",
          longitude: "126.9780",
          features: ["주차", "24시간", "CCTV", "온도 관리", "50평"],
          images: ["https://images.unsplash.com/photo-1560185007-cde436f6a4d0"]
        },
        {
          name: "송파 문정동 공유창고", 
          address: "서울특별시 송파구 문정동로 8길 지하 203호",
          city: "서울특별시",
          district: "송파구",
          latitude: "37.4877",
          longitude: "127.1258",
          features: ["주차", "24시간", "CCTV", "온도 관리", "50평"],
          images: ["https://images.unsplash.com/photo-1516321497487-e288fb19713f"]
        },
        {
          name: "역삼동 강남구 공유창고",
          address: "서울특별시 강남구 역삼동로 1층",
          city: "서울특별시", 
          district: "강남구",
          latitude: "37.4979",
          longitude: "127.0276",
          features: ["주차", "24시간", "CCTV", "온도 관리", "50평"],
          images: ["https://images.unsplash.com/photo-1564013799919-ab600027ffc6"]
        }
      ];

      const createdLocations = [];
      for (const location of locations) {
        const createdLocation = await storage.createStorageLocation(location);
        createdLocations.push(createdLocation);
      }

      // Create sample storage units for each location
      const units = [];
      for (const location of createdLocations) {
        // Small units (0.5M)
        for (let i = 0; i < 5; i++) {
          units.push({
            locationId: location.id,
            size: "0.5M",
            dimensions: "100x100x100",
            monthlyPrice: "30000",
            dailyPrice: "2000",
            quarterlyPrice: "85500",
            yearlyPrice: "306000",
            unitNumber: `${location.id}-S-${i + 1}`,
            isAvailable: true
          });
        }

        // Medium units (SB)
        for (let i = 0; i < 3; i++) {
          units.push({
            locationId: location.id,
            size: "SB",
            dimensions: "100x50x30",
            monthlyPrice: "30000",
            dailyPrice: "2000",
            quarterlyPrice: "85500", 
            yearlyPrice: "306000",
            unitNumber: `${location.id}-SB-${i + 1}`,
            isAvailable: true
          });
        }

        // Large units (M)
        for (let i = 0; i < 2; i++) {
          units.push({
            locationId: location.id,
            size: "M",
            dimensions: "150x100x150",
            monthlyPrice: "50000",
            dailyPrice: "2000",
            quarterlyPrice: "142500",
            yearlyPrice: "510000",
            unitNumber: `${location.id}-M-${i + 1}`,
            isAvailable: true
          });
        }
      }

      for (const unit of units) {
        await storage.createStorageUnit(unit);
      }

      res.json({ message: "Seed data created successfully", locations: createdLocations.length, units: units.length });
    } catch (error: any) {
      res.status(500).json({ message: "Error seeding data: " + error.message });
    }
  });

  app.post("/api/reset-storage-units", async (_req, res) => {
    try {
      // 1) 기존 데이터 삭제
      await db.delete(storageUnits);

      // 2) 신규 가격 계산 함수
      const sizeOrder = ["SB", "0.5M", "M", "2M", "3M", "4M", "XL"] as const;
      const baseMonthly = 40000;

      const calc = (size: string) => {
        const idx = sizeOrder.indexOf(size as any);
        const monthly = baseMonthly + idx * 10000;
        const daily = Math.round(monthly / 20);
        return { daily, monthly, quarterly: monthly * 3, yearly: monthly * 12 };
      };

      // 3) 모든 storage_locations 조회
      const locations = await storage.getStorageLocations();

      const dimMap: Record<string,string> = {
        "SB": "70x100x70",
        "0.5M": "90x150x90",
        "M": "120x200x120",
        "2M": "150x200x150",
        "3M": "180x200x180",
        "4M": "200x200x200",
        "XL": "250x250x250",
      };

      for (const loc of locations) {
        for (const size of sizeOrder) {
          const { daily, monthly, quarterly, yearly } = calc(size);
          for (let i = 1; i <= 5; i++) {
            await storage.createStorageUnit({
              locationId: loc.id,
              size,
              dimensions: dimMap[size] || "100x100x100",
              dailyPrice: `${daily}`,
              monthlyPrice: `${monthly}`,
              quarterlyPrice: `${quarterly}`,
              yearlyPrice: `${yearly}`,
              unitNumber: `${loc.id}-${size}-${i}`,
            });
          }
        }
      }
      res.json({ success: true, msg: "storage_units reset 완료" });
    } catch (e: any) {
      res.status(500).json({ success: false, error: e.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
