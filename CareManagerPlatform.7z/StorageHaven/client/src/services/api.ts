import axios, { InternalAxiosRequestConfig } from "axios";

// API 기본 설정
const API_URL = import.meta.env.VITE_API_URL || (import.meta.env.MODE === 'production' ? '' : 'http://localhost:5000');
const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// 요청 인터셉터 - 인증 토큰 추가
api.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const token = localStorage.getItem("authToken");
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: unknown) => Promise.reject(error),
);

// 사용자 관련 API
export const userApi = {
  // 사용자 프로필 정보 가져오기
  getProfile: () => api.get("/api/users/profile"),

  // 사용자 정보 업데이트
  updateProfile: (data: any) => api.put("/api/users/profile", data),

  // 사용자 상세 - Firebase UID로 조회
  getUserByFirebaseUid: (uid: string, email?: string, displayName?: string) => {
    // 쿼리 파라미터 구성
    const queryParams = new URLSearchParams();
    if (email) queryParams.append("email", email);
    if (displayName) queryParams.append("displayName", displayName);

    // 쿼리 문자열 생성 및 API 호출
    const queryString = queryParams.toString();
    const endpoint = `/api/users/by-firebase/${uid}${queryString ? `?${queryString}` : ""}`;

    return api.get(endpoint);
  },

  // 사용자 생성 (회원가입)
  createUser: (data: any) => api.post("/api/users", data),

  // 사용자 유형 업데이트
  updateUserType: (id: number, userType: string) =>
    api.patch(`/api/users/${id}/type`, { userType }),

  // 파트너 ID 업데이트
  updatePartnerId: (id: number, partnerId: string) =>
    api.patch(`/api/users/${id}/partner`, { partnerId }),
};

// 관리자 관련 API
export const adminApi = {
  // 가맹점 승인 요청 목록 가져오기
  getFranchiseRequests: () => api.get("/api/users/pending-franchises"),

  // 가맹점 승인
  approveFranchise: (id: number) => api.patch(`/api/users/${id}/approve`),

  // 가맹점 승인 거부
  rejectFranchise: (id: number) => api.patch(`/api/users/${id}/reject`),

  // 승인된 가맹점 목록 가져오기
  getApprovedFranchises: () => api.get("/api/admin/franchises"),

  // 슈퍼유저 권한 변경
  setSuperUser: (id: number, isSuperUser: boolean) =>
    api.patch(`/api/users/${id}/superuser`, { isSuperUser }),

  // 매출 통계 가져오기
  getRevenueStats: (period: string = "monthly") =>
    api.get(`/api/admin/stats/revenue?period=${period}`),

  // 사용자 통계 가져오기
  getUserStats: () => api.get("/api/admin/stats/users"),
};

// 창고 관련 API
export const storageApi = {
  // 창고 목록 가져오기
  getStorageLocations: () => api.get("/api/storage-locations"),
  getOwnerStorageLocations: (firebaseUid: string) =>
    api.get(`/api/users/${firebaseUid}/storage-locations`),

  // 창고 상세 정보 가져오기
  getStorageLocation: (id: number) => api.get(`/api/storage-locations/${id}`),

  // 창고 추가
  createStorageLocation: (data: any) =>
    api.post("/api/storage-locations", data),

  // 창고 정보 수정
  updateStorageLocation: (id: number, data: any) =>
    api.put(`/api/storage-locations/${id}`, data),

  // 창고 삭제
  deleteStorageLocation: (id: number) =>
    api.delete(`/api/storage-locations/${id}`),

  // 보관함(로커) 목록 가져오기
  getStorageUnits: (locationId: number) =>
    api.get(`/api/storage-locations/${locationId}/units`),
  // 이용 가능한 보관함(로커) 목록 가져오기
  getAvailableStorageUnits: (locationId: number) =>
    api.get(`/api/storage-locations/${locationId}/available-units`),
  // 예약된 보관함(로커) 목록 가져오기 (pending/active)
  getReservedUnits: (locationId: number) =>
    api.get(`/api/storage-locations/${locationId}/reserved-units`),

  // 특정 보관함(로커) 가져오기
  getStorageUnit: (id: number) => api.get(`/api/storage-units/${id}`),

  // 보관함(로커) 추가
  createStorageUnit: (locationId: number, data: any) =>
    api.post(`/api/storage-locations/${locationId}/units`, data),

  // 보관함(로커) 수정
  updateStorageUnit: (id: number, data: any) =>
    api.put(`/api/storage-units/${id}`, data),

  // 보관함(로커) 삭제
  deleteStorageUnit: (id: number) => api.delete(`/api/storage-units/${id}`),

  // 창고별 통계 데이터 가져오기
  getStorageStats: (locationId: number) =>
    api.get(`/api/storage-locations/${locationId}/stats`),
};

// 예약 관련 API
export const reservationApi = {
  // 예약 목록 가져오기
  getReservations: () => api.get("/api/reservations"),

  // 예약 상세 정보 가져오기
  getReservation: (id: number) => api.get(`/api/reservations/${id}`),

  // 예약 생성
  createReservation: (data: any) => api.post("/api/reservations", data),

  // 예약 취소
  cancelReservation: (id: number) => api.put(`/api/reservations/${id}/cancel`),

  // 파트너 ID로 예약 목록 가져오기
  getPartnerReservations: (partnerId: string) =>
    api.get(`/api/partners/${partnerId}/reservations`),

  // 파트너 정산 정보 가져오기
  getPartnerSettlements: (partnerId: string) =>
    api.get(`/api/partners/${partnerId}/settlements`),
};

export default api;
