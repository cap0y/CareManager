import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapPin, Clock, Shield, Thermometer, Car, Video, Package, TrendingUp, Loader2, Navigation, BookOpen, Sparkles, Search } from "lucide-react";
import GoogleMapComponent from "@/components/GoogleMap";
import { useLanguage } from "@/contexts/language-context";
import { commonTranslations } from "@/lib/translations";
import type { StorageLocation } from "@shared/schema";

// 확장된 StorageLocation 타입을 정의
interface StorageLocationWithDistance extends StorageLocation {
  distance?: number;
}

// 두 지점 간의 거리를 계산하는 함수 (Haversine formula)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // 지구 반경 (km)
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c; // km 단위 거리
  return distance;
}

// 간단한 자동 수평 슬라이더 컴포넌트
function ImageSlider() {
  const images = ["/images/1.jpeg", "/images/2.jpeg", "/images/3.jpeg"];
  const [index, setIndex] = useState(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    timeoutRef.current = setTimeout(() => {
      setIndex((prev) => (prev + 1) % images.length);
    }, 4000); // 4초마다 변경
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [index]);

  return (
    <div className="relative w-full h-48 overflow-hidden rounded-xl mb-6">
      <div
        className="flex w-full h-full transition-transform duration-700"
        style={{ transform: `translateX(-${index * 100}%)` }}
      >
        {images.map((src) => (
          <img
            key={src}
            src={src}
            alt="storage hero"
            className="w-full flex-shrink-0 object-cover h-48"
          />
        ))}
      </div>
      {/* 인디케이터 */}
      <div className="absolute bottom-2 left-0 right-0 flex justify-center space-x-2">
        {images.map((_, i) => (
          <span
            key={i}
            className={`w-2 h-2 rounded-full ${i === index ? 'bg-primary' : 'bg-white/40'}`}
          />
        ))}
      </div>
    </div>
  );
}

// feature-icon 매핑 함수
const featureIcon = (feature: string) => {
  const key = feature.toLowerCase();
  if (key.includes('주차')) return <Car className="w-3 h-3 mr-1" />;
  if (key.includes('24')) return <Clock className="w-3 h-3 mr-1" />;
  if (key.includes('cctv')) return <Video className="w-3 h-3 mr-1" />;
  if (key.includes('온도')) return <Thermometer className="w-3 h-3 mr-1" />;
  if (key.includes('평') || key.includes('size')) return <Package className="w-3 h-3 mr-1" />;
  return <Shield className="w-3 h-3 mr-1" />;
};

export default function Home() {
  const { language, refreshKey } = useLanguage();
  const t = commonTranslations[language]; // 번역 객체
  
  const { data: locations, isLoading } = useQuery<StorageLocation[]>({
    queryKey: ["/api/storage-locations"],
  });

  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(false);
  const [nearbyLocations, setNearbyLocations] = useState<StorageLocationWithDistance[]>([]);
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({ lat: 37.5665, lng: 126.9780 }); // 서울 중심

  // 언어 변경 감지를 위한 useEffect
  useEffect(() => {
    console.log("Home - 언어 변경됨:", language, "리프레시 키:", refreshKey);
  }, [language, refreshKey]);

  // 사용자 위치 가져오기
  const getUserLocation = () => {
    if (!navigator.geolocation) {
      alert("이 브라우저에서는 위치 정보를 사용할 수 없습니다.");
      return;
    }

    setIsLoadingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userPos = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        setUserLocation(userPos);
        setMapCenter(userPos);
        setIsLoadingLocation(false);
      },
      (error) => {
        console.error("위치 정보를 가져오는 데 실패했습니다:", error);
        setIsLoadingLocation(false);
      }
    );
  };

  // 사용자 위치와 공유창고 위치 기반으로 거리 계산
  useEffect(() => {
    if (locations && userLocation) {
      const locationsWithDistance = locations.map(location => {
        const lat = location.latitude ? Number(location.latitude) : 0;
        const lng = location.longitude ? Number(location.longitude) : 0;
        
        // 위도/경도 정보가 있는 경우에만 거리 계산
        const distance = (lat && lng) 
          ? calculateDistance(userLocation.lat, userLocation.lng, lat, lng)
          : undefined;
        
        return { ...location, distance } as StorageLocationWithDistance;
      });

      // 거리 기준으로 정렬하고 유효한 거리 정보가 있는 곳만 필터링
      const sorted = locationsWithDistance
        .filter(loc => loc.distance !== undefined)
        .sort((a, b) => (a.distance || Infinity) - (b.distance || Infinity));
      
      setNearbyLocations(sorted);
    }
  }, [locations, userLocation]);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // 표시할 공유창고 목록 (근처 위치가 있으면 그것을 사용, 없으면 전체 목록)
  const displayLocations = nearbyLocations.length > 0 && userLocation ? nearbyLocations : (locations || []) as StorageLocationWithDistance[];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Hero Section */}
      <section className="px-4 py-6">
        <div className="bg-gradient-to-r from-primary/20 to-primary/10 rounded-2xl p-6 mb-6">
          <h1 className="text-2xl font-bold mb-2">{t.selfStorage}</h1>
          <p className="text-gray-300 mb-4">{t.nearbyStorage}</p>
          
          <ImageSlider />

          <div className="flex flex-col space-y-2">
            <Button 
              onClick={getUserLocation} 
              className="w-full bg-gradient-to-r from-primary/80 to-primary/60 hover:opacity-90 text-white/90 backdrop-blur-md py-3 rounded-lg font-medium flex items-center justify-center"
              disabled={isLoadingLocation}
            >
              {isLoadingLocation ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t.searchingLocation}
                </>
              ) : (
                <>
                  <Navigation className="mr-2 h-4 w-4" />
                  {t.findNearbyStorage}
                </>
              )}
            </Button>
            
            <Link href="/locations">
              <Button className="w-full bg-gradient-to-r from-gray-700/80 to-gray-600/60 hover:opacity-90 text-white/90 backdrop-blur-md py-3 rounded-lg font-medium flex items-center justify-center">
                <Search className="mr-2 h-4 w-4" />
                {t.viewAllStorage}
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Tabbed Content */}
      <section className="px-4 py-6">
        <Tabs defaultValue="locations" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-gray-800 border-gray-700">
            <TabsTrigger value="locations" className="text-sm flex items-center gap-1 data-[state=active]:bg-primary data-[state=active]:text-white">
              <MapPin className="w-4 h-4" />
              {userLocation ? t.nearbyLocations : t.popularLocations}
            </TabsTrigger>
            <TabsTrigger value="usage" className="text-sm flex items-center gap-1 data-[state=active]:bg-primary data-[state=active]:text-white">
              <BookOpen className="w-4 h-4" />
              {t.howToUse}
            </TabsTrigger>
            <TabsTrigger value="features" className="text-sm flex items-center gap-1 data-[state=active]:bg-primary data-[state=active]:text-white">
              <Sparkles className="w-4 h-4" />
              {t.facilityFeatures}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="locations" className="mt-6">
            {displayLocations && displayLocations.length > 0 ? (
              <div className="space-y-3">
                {displayLocations.slice(0, 5).map((location) => (
                  <Link key={location.id} href={`/storage/${location.id}`}>
                    <Card className="bg-gray-800 border-gray-700 hover:bg-gray-700 transition-colors">
                      <CardContent className="p-4">
                        <div className="flex items-start space-x-3">
                          <img 
                            src={(location.images as string[] | undefined)?.[0] || "https://images.unsplash.com/photo-1560185007-cde436f6a4d0"} 
                            alt={location.name}
                            className="w-16 h-12 object-cover rounded-lg"
                          />
                          <div className="flex-1">
                            <h4 className="font-medium text-white mb-1">{location.name}</h4>
                            <p className="text-sm text-gray-400 mb-2">{location.address}</p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-1 text-xs overflow-x-auto no-scrollbar">
                                {(location.features as string[] | undefined)?.map((feature, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs px-1.5 whitespace-nowrap">
                                    {feature}
                                  </Badge>
                                ))}
                              </div>
                              {location.distance !== undefined && (
                                <Badge variant="outline" className="text-xs bg-primary/10 text-primary border-primary/30">
                                  {location.distance < 1 
                                    ? `${Math.round(location.distance * 1000)}m` 
                                    : `${location.distance.toFixed(1)}km`}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}

                {/* 구글 맵 컴포넌트 추가 */}
                <div className="mt-6 rounded-xl overflow-hidden">
                  <GoogleMapComponent 
                    center={mapCenter}
                    zoom={userLocation ? 14 : 12}
                    height="400px"
                    fitBounds={true}
                    markers={[
                      ...(userLocation ? [{
                        position: userLocation,
                        title: "내 위치",
                      }] : []),
                      ...displayLocations
                        .filter(loc => loc.latitude && loc.longitude)
                        .map(location => ({
                          position: { lat: Number(location.latitude), lng: Number(location.longitude) },
                          title: location.name,
                          address: location.address,
                          image: (location.images as string[] | undefined)?.[0]
                        }))
                    ]}
                  />
                </div>
                
                <Link href="/locations">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white py-3 rounded-lg font-medium mt-4 flex items-center justify-center gap-2">
                    <Search className="w-4 h-4" />
                    {t.viewAll}
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-400">{t.noLocations}</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="usage" className="mt-6">
            <Card className="bg-gray-800 border-gray-700 text-gray-200">
              <CardContent className="p-6 text-gray-200">
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <MapPin className="text-gray-600 w-8 h-8" />
                    </div>
                    <div className="text-sm text-gray-400 mb-1">STEP 01</div>
                    <div className="font-medium text-white">{t.step1Title}</div>
                  </div>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <div className="text-gray-600 w-8 h-8 flex items-center justify-center">
                        <div className="w-6 h-6 bg-primary rounded border-2 border-gray-600"></div>
                      </div>
                    </div>
                    <div className="text-sm text-gray-400 mb-1">STEP 02</div>
                    <div className="font-medium text-white">{t.step2Title}</div>
                  </div>
                </div>
                
                <div className="space-y-4 text-sm text-gray-600">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-white">{t.step1Title}</p>
                      <p className="text-gray-300">{t.step1Desc}</p>
                    </div>
                  </div>
                  
                  {/* 지도 추가 */}
                  <div className="mt-4 mb-4 rounded-lg overflow-hidden border border-gray-200">
                    <GoogleMapComponent 
                      center={mapCenter}
                      zoom={userLocation ? 14 : 12}
                      height="250px"
                      markers={[
                        ...(userLocation ? [{
                          position: userLocation,
                          title: "내 위치",
                        }] : []),
                        ...displayLocations.map(location => ({
                          position: { 
                            lat: location.latitude ? Number(location.latitude) : 37.5665, 
                            lng: location.longitude ? Number(location.longitude) : 126.9780 
                          },
                          title: location.name,
                          address: location.address
                        }))
                      ]}
                    />
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-white">{t.step2Title}</p>
                      <p className="text-gray-300">{t.step2Desc}</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <div>
                      <p className="font-medium text-white">{t.step3Title}</p>
                      <p className="text-gray-300">{t.step3Desc}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="features" className="mt-6">
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-gray-800 border-gray-700 p-4 text-center">
                <Clock className="text-primary w-8 h-8 mx-auto mb-2" />
                <p className="text-sm font-medium">{t.openAllDay}</p>
              </Card>
              <Card className="bg-gray-800 border-gray-700 p-4 text-center">
                <Thermometer className="text-primary w-8 h-8 mx-auto mb-2" />
                <p className="text-sm font-medium">{t.temperature}</p>
              </Card>
              <Card className="bg-gray-800 border-gray-700 p-4 text-center">
                <Video className="text-primary w-8 h-8 mx-auto mb-2" />
                <p className="text-sm font-medium">{t.cctv}</p>
              </Card>
              <Card className="bg-gray-800 border-gray-700 p-4 text-center">
                <Shield className="text-primary w-8 h-8 mx-auto mb-2" />
                <p className="text-sm font-medium">{t.security}</p>
              </Card>
              <Card className="bg-gray-800 border-gray-700 p-4 text-center">
                <Car className="text-primary w-8 h-8 mx-auto mb-2" />
                <p className="text-sm font-medium">{t.parking}</p>
              </Card>
              <Card className="bg-gray-800 border-gray-700 p-4 text-center">
                <Package className="text-primary w-8 h-8 mx-auto mb-2" />
                <p className="text-sm font-medium">{t.storage}</p>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </section>
    </div>
  );
}
