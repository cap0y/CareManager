import { useEffect, useState, useCallback } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/contexts/auth-context";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut, User, UserCheck, UserX, Building, BarChart3, ShieldCheck } from "lucide-react";
import { adminApi, storageApi } from "@/services/api";
import type { FranchiseRequest, StorageLocation, StorageUnit, RevenueStats, StorageLocationForm, StorageUnitForm, User as IUser } from "@/types/storage";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { userApi } from "@/services/api";
import AddressSearch from "@/components/ui/address-search";


// 임시 가맹점 요청 데이터 인터페이스 및 더미 데이터 제거


export default function ProfilePage() {
  const [location, setLocation] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const params = useParams();
  
  // 탭 상태 관리
  const [activeTab, setActiveTab] = useState(params.tab || "profile");
  const [adminActiveTab, setAdminActiveTab] = useState("approvals");
  const [allReservations, setAllReservations] = useState<any[]>([]);
  
  // 파트너 ID 상태
  const [partnerId, setPartnerId] = useState<string>("");
  const [partnerIdSaving, setPartnerIdSaving] = useState<boolean>(false);
  const [partnerIdMessage, setPartnerIdMessage] = useState<{type: 'success' | 'error', message: string} | null>(null);

  // 파트너 ID 저장
  const savePartnerId = async () => {
    if (!user?.backendId) return;
    
    setPartnerIdSaving(true);
    setPartnerIdMessage(null);
    
    try {
      await userApi.updatePartnerId(user.backendId, partnerId);
      setPartnerIdMessage({
        type: 'success',
        message: '파트너 ID가 성공적으로 저장되었습니다.'
      });
      
      // 새로고침 없이 사용자 정보 업데이트
      const { data } = await userApi.getUserByFirebaseUid(user.id);
      if (data?.user) {
        // localStorage의 사용자 정보 업데이트
        const updatedUser = {
          ...user,
          partnerId: data.user.partnerId
        };
        localStorage.setItem('auth_user', JSON.stringify(updatedUser));
      }
    } catch (error) {
      console.error("파트너 ID 저장 오류:", error);
      setPartnerIdMessage({
        type: 'error',
        message: '파트너 ID 저장 중 오류가 발생했습니다.'
      });
    } finally {
      setPartnerIdSaving(false);
    }
  };

  // 컴포넌트 마운트시 파트너 ID 로드
  useEffect(() => {
    if (user?.partnerId) {
      setPartnerId(user.partnerId);
    }
  }, [user]);

  // 데이터 로드 함수들
  const fetchFranchiseRequests = async () => {
    try {
      const { data } = await adminApi.getFranchiseRequests();
      if (Array.isArray(data)) {
        setFranchiseRequests(data);
      } else if (Array.isArray(data?.pendingFranchises)) {
        setFranchiseRequests(data.pendingFranchises);
      }
    } catch (error) {
      console.error("가맹점 요청 조회 오류:", error);
    }
  };

  const fetchStorageLocations = async () => {
    try {
      const { data } = await storageApi.getStorageLocations();
      setStorageLocations(data);
    } catch (error) {
      console.error("창고 목록 조회 오류:", error);
    }
  };

  const fetchStorageUnits = async (locationId: number) => {
    try {
      const { data } = await storageApi.getStorageUnits(locationId);
      setStorageUnits(data);
      const map: Record<string, {daily:number,monthly:number,quarterly:number,yearly:number}> = {};
      data.forEach((u: StorageUnit) => {
        if (!map[u.size]) {
          map[u.size] = {
            daily: Number(u.dailyPrice),
            monthly: Number(u.monthlyPrice),
            quarterly: Number(u.quarterlyPrice),
            yearly: Number(u.yearlyPrice),
          };
        }
      });
      setUnitPriceMap(map);
    } catch (error) {
      console.error("보관함 목록 조회 오류:", error);
    }
  };

  const fetchRevenueStats = async () => {
    try {
      const { data } = await adminApi.getRevenueStats("monthly");
      setRevenueStats(data);
    } catch (error) {
      console.error("매출 통계 조회 오류:", error);
    }
  };

  // 전체 예약 조회 (관리자)
  const fetchAllReservations = async () => {
    try {
      const res = await fetch(`/api/admin/reservations?ts=${Date.now()}`);
      const json = await res.json();
      if (json.success && Array.isArray(json.reservations)) {
        setAllReservations(json.reservations);
      } else {
        setAllReservations([]);
      }
    } catch (e) {
      console.error("예약 목록 조회 오류:", e);
    }
  };

  // 승인/거부 처리
  const handleApprove = async (franchiseId: number) => {
    try {
      await adminApi.approveFranchise(franchiseId);
      await fetchFranchiseRequests();
    } catch (error) {
      console.error("승인 오류:", error);
    }
  };

  const handleReject = async (franchiseId: number) => {
    try {
      await adminApi.rejectFranchise(franchiseId);
      await fetchFranchiseRequests();
    } catch (error) {
      console.error("거부 오류:", error);
    }
  };

  // 로그인 상태가 아니면 로그인 페이지로 리디렉션
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
    
    // URL 파라미터에 따라 탭 설정
    if (params.tab) {
      setActiveTab(params.tab);
    }
  }, [isAuthenticated, setLocation, params.tab]);

  // 가맹점 승인 처리
  // 가맹점 승인 거부
  // const handleRejectOld = (franchiseId: string) => {
  //   // setFranchiseRequests(prev => prev.filter(f => f.id !== franchiseId));
  //   // 여기서 Firestore 업데이트 로직 추가 필요
  // };

  const handleLogout = async () => {
    try {
      await logout();
      setLocation("/");
    } catch (error) {
      console.error("로그아웃 오류:", error);
    }
  };

  // 인증되지 않은 경우 렌더링하지 않음 (모든 훅 선언 이후 위치)
  if (!isAuthenticated) {
    return null;
  }

  // 관리자인지 확인
  const isAdmin = user?.userType === 'admin';
  
  // 가맹점 주인인지 확인
  const isFranchise = user?.userType === 'franchise';

  const [franchiseRequests, setFranchiseRequests] = useState<FranchiseRequest[]>([]);
  const [storageLocations, setStorageLocations] = useState<StorageLocation[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<StorageLocation | null>(null);
  const [storageUnits, setStorageUnits] = useState<StorageUnit[]>([]);
  const [revenueStats, setRevenueStats] = useState<RevenueStats | null>(null);
  const [approvedFranchises, setApprovedFranchises] = useState<IUser[]>([]);
  const [unitPriceMap, setUnitPriceMap] = useState<Record<string, {daily:number,monthly:number,quarterly:number,yearly:number}>>({});

  const fetchApprovedFranchises = async () => {
    try {
      const { data } = await adminApi.getApprovedFranchises();
      if (Array.isArray(data)) {
        setApprovedFranchises(data);
      } else if (Array.isArray(data?.franchises)) {
        setApprovedFranchises(data.franchises);
      }
    } catch (error) {
      console.error("가맹점 목록 조회 오류:", error);
    }
  };

  const handleToggleSuperUser = async (uid: number, current: boolean) => {
    try {
      await adminApi.setSuperUser(uid, !current);
      fetchApprovedFranchises();
    } catch (e) {
      console.error("슈퍼유저 권한 변경 오류:", e);
    }
  };

  // 폼 관련 상태
  const [showLocationForm, setShowLocationForm] = useState(false);
  const [newLocation, setNewLocation] = useState<StorageLocationForm & { images: string[] }>({
    name: "",
    address: "",
    city: "",
    district: "",
    latitude: undefined,
    longitude: undefined,
    features: [],
    images: [],
  });

  // 창고 특징 문자열 상태 (쉼표 구분)
  const [features, setFeatures] = useState<string>("주차,24시간,CCTV,온도 관리,50평");

  // 이미지 파일 선택 처리 – 최대 3개, base64 변환 후 preview
  const handleImageFiles = useCallback((files: FileList | null) => {
    if (!files) return;
    const arr = Array.from(files).slice(0, 3);
    Promise.all(
      arr.map(
        (f) =>
          new Promise<string>((res) => {
            const reader = new FileReader();
            reader.onload = () => res(reader.result as string);
            reader.readAsDataURL(f);
          })
      )
    ).then((base64s) => {
      setNewLocation((prev) => ({ ...prev, images: base64s }));
    });
  }, []);

  const [unitFormLocationId, setUnitFormLocationId] = useState<number | null>(null);

  const sizeDimensionMap: Record<string, string[]> = {
    SB: ["70cm×100cm×70cm"],
    "0.5M": ["90cm×150cm×90cm"],
    M: ["120cm×200cm×120cm"],
    "2M": ["150cm×200cm×150cm"],
    "3M": ["180cm×200cm×180cm"],
    "4M": ["200cm×200cm×200cm"],
    XL: ["250cm×250cm×250cm"],
  };

  // 사이즈 순서 및 요금 계산 헬퍼
  const sizeOrder = ["SB", "0.5M", "M", "2M", "3M", "4M", "XL"] as const;

  const priceBase = {
    daily: 2000,
    monthly: 40000,
  };

  const getPricesForSize = (size: string) => {
    const price = unitPriceMap[size];
    if (price) {
      return {
        daily: price.daily,
        monthly: price.monthly,
        quarterly: price.quarterly,
        yearly: price.yearly,
      };
    }
    const index = sizeOrder.indexOf(size as any);
    const delta = index >= 0 ? index : 0;
    const monthly = priceBase.monthly + delta * 10000;
    const daily = Math.round(monthly / 20);
    const quarterly = monthly * 3;
    const yearly = monthly * 12;
    return { daily, monthly, quarterly, yearly };
  };

  const generateUnitNumbers = (locId: number, size: string) => {
    const existing = storageUnits.filter(u => u.size === size).map(u => u.unitNumber);
    const numbers: string[] = [];
    for (let i = 1; i <= 50; i++) {
      const candidate = `${locId}-${size}-${i}`;
      if (!existing.includes(candidate)) numbers.push(candidate);
    }
    return numbers;
  };

  const priceInit = getPricesForSize("SB");

  const [newUnit, setNewUnit] = useState<StorageUnitForm>({
    locationId: 0,
    size: "SB",
    dimensions: "",
    dailyPrice: priceInit.daily,
    monthlyPrice: priceInit.monthly,
    quarterlyPrice: priceInit.quarterly,
    yearlyPrice: priceInit.yearly,
    unitNumber: "",
  });

  useEffect(() => {
    if (!isAdmin) return;

    if (adminActiveTab === "approvals") {
      fetchFranchiseRequests();
    } else if (adminActiveTab === "storages") {
      fetchStorageLocations();
    } else if (adminActiveTab === "franchises") {
      fetchApprovedFranchises();
      fetchStorageLocations();
    } else if (adminActiveTab === "superusers") {
      fetchApprovedFranchises();
    } else if (adminActiveTab === "reservations") {
      fetchAllReservations();
    }
  }, [adminActiveTab, isAdmin]);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">내 계정</h1>
      
      {/* 프로필 정보 카드 */}
      <Card className="bg-gray-800 border-gray-700 mb-6">
        <CardHeader className="pb-2">
          <CardTitle>프로필 정보</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              {user?.photoURL ? (
                <AvatarImage src={user.photoURL} alt={user.displayName} />
              ) : (
                <AvatarFallback className="bg-primary/20 text-primary">
                  <User className="h-12 w-12" />
                </AvatarFallback>
              )}
            </Avatar>
            
            <div>
              <h2 className="text-xl font-semibold">{user?.displayName}</h2>
              <p className="text-gray-400">{user?.email}</p>
              <div className="flex items-center mt-1">
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs 
                  ${user?.userType === 'admin' ? 'bg-red-500/20 text-red-400' : 
                    user?.userType === 'franchise' ? 'bg-blue-500/20 text-blue-400' : 
                    'bg-green-500/20 text-green-400'}`
                }>
                  {user?.userType === 'admin' ? '관리자' : 
                   user?.userType === 'franchise' ? '가맹점 회원' : 
                   '일반 회원'}
                </span>
                
                {user?.userType === 'franchise' && (
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ml-2
                    ${user?.isApproved ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`
                  }>
                    {user?.isApproved ? '승인됨' : '승인 대기중'}
                  </span>
                )}
              </div>
            </div>
          </div>
          
          {/* 가맹점 회원 정보 표시 (있을 경우) */}
          {isFranchise && (
            <div className="mt-4 pt-4 border-t border-gray-700">
              <h3 className="text-lg font-medium mb-2">가맹점 정보</h3>
              
              {user?.isApproved ? (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm text-gray-400 block mb-1">포트원 파트너 ID</label>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          value={partnerId} 
                          onChange={(e) => setPartnerId(e.target.value)}
                          placeholder="파트너 ID를 입력하세요"
                          className="px-3 py-2 bg-gray-800 border-gray-600 rounded flex-1"
                        />
                        <Button 
                          onClick={savePartnerId}
                          disabled={partnerIdSaving || !partnerId}
                          className={`${partnerId ? 'bg-blue-600 hover:bg-blue-700' : 'bg-gray-600'}`}
                        >
                          {partnerIdSaving ? '저장 중...' : '저장'}
                        </Button>
                      </div>
                      
                      {partnerIdMessage && (
                        <p className={`text-xs mt-1 ${partnerIdMessage.type === 'success' ? 'text-green-400' : 'text-red-400'}`}>
                          {partnerIdMessage.message}
                        </p>
                      )}
                    </div>
                    
                    <div>
                      <label className="text-sm text-gray-400 block mb-1">정산 상태</label>
                      <div className="px-3 py-2 bg-gray-800 border-gray-600 rounded">
                        {user?.partnerId ? (
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-green-400"></span>
                            <span>정산 설정 완료</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-yellow-400"></span>
                            <span>정산 설정 필요</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium mb-1">정산 안내</h4>
                    <div className="bg-gray-700/50 p-3 rounded-lg text-xs text-gray-300">
                      <p>• 결제금액의 90%가 파트너에게 자동 정산됩니다.</p>
                      <p>• 정산은 매월 15일에 이루어집니다.</p>
                      <p>• 정산 내역은 포트원 파트너센터에서 확인 가능합니다.</p>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-gray-300">
                  가맹점 정보는 관리자 승인 후 확인할 수 있습니다.
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* 관리자 전용 기능 */}
      {isAdmin && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">관리자 대시보드</h2>
            <div className="bg-red-500/20 text-red-400 px-3 py-1 rounded-full text-sm font-medium flex items-center">
              <ShieldCheck className="mr-1 h-4 w-4" />
              관리자
            </div>
          </div>
          
          <Tabs 
            defaultValue="approvals" 
            value={adminActiveTab}
            onValueChange={setAdminActiveTab}
            className="space-y-4"
          >
            <TabsList className="grid grid-cols-5 mb-4">
              <TabsTrigger value="approvals">가맹점 승인</TabsTrigger>
              <TabsTrigger value="franchises">가맹점 관리</TabsTrigger>
              <TabsTrigger value="storages">창고 관리</TabsTrigger>
              <TabsTrigger value="superusers">권한 관리</TabsTrigger>
              <TabsTrigger value="reservations">예약 관리</TabsTrigger>
            </TabsList>
            
            {/* 가맹점 승인 탭 */}
            <TabsContent value="approvals">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>승인 대기 가맹점</CardTitle>
                  <CardDescription>가맹점 등록 요청 목록입니다.</CardDescription>
                </CardHeader>
                <CardContent>
                  {franchiseRequests.length > 0 ? (
                    <div className="space-y-4">
                      {franchiseRequests.map(franchise => (
                        <Card key={franchise.id} className="bg-gray-700 border-gray-600">
                          <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <h3 className="text-lg font-semibold">{franchise.franchiseInfo.name}</h3>
                                <p className="text-gray-300 text-sm">{franchise.user?.displayName} ({franchise.user?.email})</p>
                                <p className="text-gray-400 text-xs mt-1">신청일: {franchise.createdAt}</p>
                                
                                <div className="mt-2 text-sm text-gray-300">
                                  <p>주소: {franchise.franchiseInfo.address}</p>
                                  <p>연락처: {franchise.franchiseInfo.phone}</p>
                                </div>
                              </div>
                              
                              <div className="flex gap-2">
                                <Button 
                                  onClick={() => handleApprove(franchise.id)}
                                  className="bg-green-600 hover:bg-green-700"
                                >
                                  <UserCheck className="mr-1 h-4 w-4" />
                                  승인
                                </Button>
                                <Button 
                                  onClick={() => handleReject(franchise.id)}
                                  className="bg-gray-600 hover:bg-gray-500"
                                >
                                  <UserX className="mr-1 h-4 w-4" />
                                  거부
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center py-8 text-gray-400">
                      현재 승인 대기 중인 가맹점이 없습니다.
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* 가맹점 관리 탭 */}
            <TabsContent value="franchises">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>등록된 가맹점 관리</CardTitle>
                  <CardDescription>승인된 가맹점 목록입니다.</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-700 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-400 text-sm">총 가맹점</span>
                        <Building className="h-5 w-5 text-blue-400" />
                      </div>
                      <p className="text-2xl font-bold">{approvedFranchises.length}</p>
                    </div>
                    <div className="bg-gray-700 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-400 text-sm">총 창고 수</span>
                        <Building className="h-5 w-5 text-green-400" />
                      </div>
                      <p className="text-2xl font-bold">{storageLocations.length}</p>
                    </div>
                    <div className="bg-gray-700 p-4 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-gray-400 text-sm">보관함 이용률</span>
                        <BarChart3 className="h-5 w-5 text-yellow-400" />
                      </div>
                      <p className="text-2xl font-bold">67%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* 창고 관리 탭 */}
            <TabsContent value="storages">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                  <CardTitle>창고 관리</CardTitle>
                  <CardDescription>등록된 모든 창고 목록입니다.</CardDescription>
                    </div>
                    <Button 
                      className="bg-blue-600 hover:bg-blue-700"
                      onClick={() => setShowLocationForm(true)}
                    >
                      창고 추가
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {showLocationForm && (
                    <div className="mb-6 p-4 border border-gray-600 rounded-lg bg-gray-700">
                      <h3 className="text-lg font-semibold mb-2">새 창고 등록</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input 
                          type="text"
                          placeholder="창고 이름"
                          className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                          value={newLocation.name}
                          onChange={e => setNewLocation({ ...newLocation, name: e.target.value })}
                        />
                        <AddressSearch 
                          onSelect={({ roadAddr, siNm, sggNm, latitude, longitude }) => {
                            setNewLocation({
                              ...newLocation,
                              address: roadAddr,
                              city: siNm,
                              district: sggNm,
                              latitude,
                              longitude,
                            });
                          }}
                        />
                        <input 
                          type="text"
                          placeholder="도시"
                          className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                          value={newLocation.city}
                          onChange={e => setNewLocation({ ...newLocation, city: e.target.value })}
                        />
                        <input 
                          type="text"
                          placeholder="구/군"
                          className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                          value={newLocation.district}
                          onChange={e => setNewLocation({ ...newLocation, district: e.target.value })}
                        />

                        {/* 이미지 업로드 */}
                        <div className="flex items-center gap-2 col-span-2">
                          <input
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={(e) => handleImageFiles(e.target.files)}
                            className="text-sm text-gray-300"
                          />
                          <span className="text-xs text-gray-400">창고 이미지 최대 3개</span>
                        </div>

                        {/* 창고 특징 */}
                        <div className="col-span-2">
                          <label className="text-sm text-gray-300 mb-1 block">창고 특징 (쉼표로 구분)</label>
                          <textarea
                            className="w-full px-3 py-2 bg-gray-800 border-gray-600 rounded text-sm text-gray-300"
                            rows={2}
                            placeholder="주차,24시간,CCTV,온도 관리,50평"
                            value={features}
                            onChange={(e) => setFeatures(e.target.value)}
                          />
                        </div>

                        {newLocation.images && newLocation.images.length > 0 && (
                          <div className="flex space-x-2 mt-2 col-span-2">
                            {newLocation.images.map((img, i) => (
                              <img key={i} src={img} alt="preview" className="h-16 w-16 object-cover rounded" />
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Button 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={async () => {
                            try {
                              const featuresArray = features
                                .split(',')
                                .map((f) => f.trim())
                                .filter((f) => f);

                              await storageApi.createStorageLocation({
                                ...newLocation,
                                features: featuresArray,
                                ownerId: user?.id,
                              });
                              // 폼을 닫지 않고 초기화만 수행하여 연속 등록 가능
                              setNewLocation({
                                name: "",
                                address: "",
                                city: "",
                                district: "",
                                features: [],
                                images: [],
                              });
                              setFeatures("주차,24시간,CCTV,온도 관리,50평");
                              fetchStorageLocations();
                            } catch (error) {
                              console.error("창고 생성 오류:", error);
                            }
                          }}
                        >
                          저장
                        </Button>
                        <Button variant="outline" onClick={() => setShowLocationForm(false)}>
                          취소
                        </Button>
                      </div>
                    </div>
                  )}

                  {storageLocations.length > 0 ? (
                    <div className="space-y-4">
                      {storageLocations.map(loc => (
                        <Card key={loc.id} className="bg-gray-700 border-gray-600 p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="text-lg font-semibold">{loc.name}</h3>
                              <p className="text-gray-300 text-sm">{loc.address}</p>
                              <p className="text-gray-400 text-xs mt-1">{loc.city} {loc.district}</p>
                            </div>
                            <Button 
                              variant="outline"
                              onClick={() => {
                                setSelectedLocation(loc);
                                fetchStorageUnits(loc.id);
                                setUnitFormLocationId(prev => prev === loc.id ? null : loc.id);
                              }}
                            >
                              보관함 관리
                            </Button>
                          </div>

                          {unitFormLocationId === loc.id && (
                            <div className="mt-6 p-4 border border-gray-600 rounded-lg bg-gray-700">
                              <h3 className="text-lg font-semibold mb-2">{loc.name} - 보관함 추가</h3>
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <Select
                                  value={newUnit.size}
                                  onValueChange={(val) => {
                                    setNewUnit({ ...newUnit, size: val });
                                    const prices = getPricesForSize(val);
                                    setNewUnit(prev=>({...prev,dailyPrice:prices.daily,monthlyPrice:prices.monthly,quarterlyPrice:prices.quarterly,yearlyPrice:prices.yearly}));
                                  }}
                                >
                                  <SelectTrigger className="bg-gray-800 border-gray-600" >
                                    <SelectValue placeholder="사이즈" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="SB">SB</SelectItem>
                                    <SelectItem value="0.5M">0.5M</SelectItem>
                                    <SelectItem value="M">M</SelectItem>
                                    <SelectItem value="2M">2M</SelectItem>
                                    <SelectItem value="3M">3M</SelectItem>
                                    <SelectItem value="4M">4M</SelectItem>
                                    <SelectItem value="XL">XL</SelectItem>
                                  </SelectContent>
                                </Select>
                                {/* Dimensions select */}
                                <Select
                                  value={newUnit.dimensions}
                                  onValueChange={(val) => setNewUnit({ ...newUnit, dimensions: val })}
                                >
                                  <SelectTrigger className="bg-gray-800 border-gray-600" >
                                    <SelectValue placeholder="규격" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {(sizeDimensionMap[newUnit.size] || []).map(dim => (
                                      <SelectItem key={dim} value={dim}>{dim}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                {/* Unit number select */}
                                <Select
                                  value={newUnit.unitNumber}
                                  onValueChange={(val) => setNewUnit({ ...newUnit, unitNumber: val })}
                                >
                                  <SelectTrigger className="bg-gray-800 border-gray-600" >
                                    <SelectValue placeholder="유닛 번호" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {generateUnitNumbers(loc.id, newUnit.size || "SB").map(num => (
                                      <SelectItem key={num} value={num}>{num}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                                <input 
                                  type="number"
                                  placeholder="일 요금"
                                  className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                                  value={newUnit.dailyPrice || ""}
                                  onChange={e => setNewUnit({ ...newUnit, dailyPrice: Number(e.target.value) })}
                                />
                                <input 
                                  type="number"
                                  placeholder="월 요금"
                                  className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                                  value={newUnit.monthlyPrice || ""}
                                  onChange={e => setNewUnit({ ...newUnit, monthlyPrice: Number(e.target.value) })}
                                />
                                <input 
                                  type="number"
                                  placeholder="분기 요금"
                                  className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                                  value={newUnit.quarterlyPrice || ""}
                                  onChange={e => setNewUnit({ ...newUnit, quarterlyPrice: Number(e.target.value) })}
                                />
                                <input 
                                  type="number"
                                  placeholder="연 요금"
                                  className="px-3 py-2 bg-gray-800 border-gray-600 rounded"
                                  value={newUnit.yearlyPrice || ""}
                                  onChange={e => setNewUnit({ ...newUnit, yearlyPrice: Number(e.target.value) })}
                                />
                              </div>
                              <div className="flex gap-2 mt-4">
                                <Button 
                                  className="bg-green-600 hover:bg-green-700"
                                  onClick={async () => {
                                    try {
                                      await storageApi.createStorageUnit(loc.id, { ...newUnit, locationId: loc.id });
                                      // 폼을 닫지 않고 초기화만 수행하여 연속 등록 가능
                                      setNewUnit({ locationId: loc.id, size: "SB", dimensions: "", dailyPrice: priceInit.daily, monthlyPrice: priceInit.monthly, quarterlyPrice: priceInit.quarterly, yearlyPrice: priceInit.yearly, unitNumber: "" });
                                      fetchStorageUnits(loc.id);
                                    } catch (error) {
                                      console.error("보관함 추가 오류:", error);
                                    }
                                  }}
                                >
                                  저장
                                </Button>
                                <Button variant="outline" onClick={() => setUnitFormLocationId(null)}>
                                  취소
                                </Button>
                              </div>
                              {storageUnits.length > 0 && (
                                <div className="mt-6">
                                  <h4 className="font-semibold mb-2">등록된 보관함</h4>
                                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                                    {storageUnits.map(unit => (
                                      <div key={unit.id} className="p-2 bg-gray-800 border-gray-600 rounded text-sm">
                                        {unit.unitNumber} - {unit.size} - {unit.isAvailable ? '사용 가능' : '사용 중'}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center py-8 text-gray-400">등록된 창고가 없습니다.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* 권한 관리 탭 */}
            <TabsContent value="superusers">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>슈퍼유저 권한 관리</CardTitle>
                  <CardDescription>가맹점 회원에게 슈퍼유저 권한을 부여하거나 해제합니다.</CardDescription>
                </CardHeader>
                <CardContent>
                  {approvedFranchises.length > 0 ? (
                    <div className="space-y-4">
                      {approvedFranchises.map(f => (
                        <Card key={f.id} className="bg-gray-700 border-gray-600 p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="text-lg font-semibold">{f.displayName || f.username}</h3>
                              <p className="text-gray-300 text-sm">{f.email}</p>
                            </div>
                            <Button
                              onClick={() => handleToggleSuperUser(f.id, f.isSuperUser)}
                              className={f.isSuperUser ? "bg-gray-600 hover:bg-gray-500" : "bg-purple-600 hover:bg-purple-700"}
                            >
                              {f.isSuperUser ? "권한 해제" : "슈퍼유저 부여"}
                            </Button>
                          </div>
                        </Card>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center py-8 text-gray-400">승인된 가맹점이 없습니다.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* 예약 관리 탭 */}
            <TabsContent value="reservations">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>예약자 관리</CardTitle>
                  <CardDescription>전체 예약 내역</CardDescription>
                </CardHeader>
                <CardContent>
                  {allReservations.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full text-sm">
                        <thead>
                          <tr className="bg-gray-700">
                            <th className="px-2 py-1">ID</th>
                            <th className="px-2 py-1">이름</th>
                            <th className="px-2 py-1">이메일</th>
                            <th className="px-2 py-1">전화</th>
                            <th className="px-2 py-1">로커</th>
                            <th className="px-2 py-1">기간</th>
                            <th className="px-2 py-1">금액</th>
                            <th className="px-2 py-1">상태</th>
                          </tr>
                        </thead>
                        <tbody>
                          {allReservations.map((r:any)=>(
                            <tr key={r.reservationId} className="border-b border-gray-700 hover:bg-gray-800">
                              <td className="px-2 py-1">{r.reservationId}</td>
                              <td className="px-2 py-1">{r.userName||'-'}</td>
                              <td className="px-2 py-1">{r.userEmail}</td>
                              <td className="px-2 py-1">{r.userPhone||'-'}</td>
                              <td className="px-2 py-1">{r.unitNumber||'-'}</td>
                              <td className="px-2 py-1">{new Date(r.startDate).toLocaleDateString()}~{new Date(r.endDate).toLocaleDateString()}</td>
                              <td className="px-2 py-1">{Number(r.totalAmount).toLocaleString()}원</td>
                              <td className="px-2 py-1">
                                <select
                                  className="bg-gray-800 border-gray-600 text-white text-xs px-2 py-1 rounded"
                                  value={r.status}
                                  onChange={async (e)=>{
                                    const newStatus=e.target.value;
                                    try{
                                      await fetch(`/api/admin/reservations/${r.reservationId}/status`,{
                                        method:'PATCH',
                                        headers:{'Content-Type':'application/json'},
                                        body:JSON.stringify({status:newStatus})
                                      });
                                      fetchAllReservations();
                                    }catch(err){console.error('status update',err);}
                                  }}
                                >
                                  {['pending','active','expired','cancelled'].map(s=>(
                                    <option key={s} value={s}>{s}</option>
                                  ))}
                                </select>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-center py-6 text-gray-400">예약 데이터가 없습니다.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}
      
      <div className="flex items-center gap-4">
        <Button variant="outline" className="bg-gray-800 border-gray-700 hover:bg-gray-700">
          개인정보 수정
        </Button>
        
        <Button 
          variant="destructive" 
          onClick={handleLogout}
          className="bg-red-900/30 hover:bg-red-900/50 text-red-400"
        >
          <LogOut className="mr-2 h-4 w-4" />
          로그아웃
        </Button>
      </div>
    </div>
  );
} 