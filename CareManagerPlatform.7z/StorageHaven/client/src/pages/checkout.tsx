import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, CreditCard, FileEdit } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { StorageUnit } from "@shared/schema";

// PortOne configuration
declare global {
  interface Window {
    PortOne: any;
  }
}

// 1) PaymentForm 타입 및 파라미터에 daysBetween 추가
function PaymentForm({ unit, period, amount, customerInfo, daysBetween, startDate, endDate }: { 
  unit: StorageUnit; 
  period: string; 
  amount: number; 
  customerInfo: { name: string; email: string; phone: string },
  daysBetween: number;
  startDate: string | null;
  endDate: string | null;
}) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [, setLocation] = useLocation();

  const handlePayment = async () => {
    if (!window.PortOne) {
      toast({
        title: "결제 시스템 오류",
        description: "결제 시스템을 불러오는 중입니다. 잠시 후 다시 시도해주세요.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);

    try {
      // Create payment order
      const orderResponse = await apiRequest("POST", "/api/create-payment", {
        amount,
        orderName: `${unit.size} 보관함 ${period === "daily" ? `${daysBetween}일` : period === "monthly" ? "1개월" : period === "quarterly" ? "3개월" : "12개월"} 이용`,
        unitId: unit.id,
        customerEmail: customerInfo.email,
        customerName: customerInfo.name,
        startDate,
        endDate,
        period,
      });

      const orderData = await orderResponse.json();

      if (!orderData.success) {
        throw new Error(orderData.message || "주문 생성 실패");
      }

      // Initialize PortOne payment
      const response = await window.PortOne.requestPayment({
        storeId: "store-e4038486-8d83-41a5-acf1-844a009e0d94",
        paymentId: orderData.orderId,
        orderName: orderData.orderName,
        totalAmount: amount,
        currency: "KRW",
        channelKey: "channel-key-fc5f33bb-c51e-4ac7-a0df-4dc40330046d",
        payMethod: "CARD",
        customer: {
          fullName: customerInfo.name,
          email: customerInfo.email,
          phoneNumber: customerInfo.phone,
        },
        redirectUrl: `${window.location.origin}/payment/success`,
        failRedirectUrl: `${window.location.origin}/payment/failure`,
        noticeUrls: [`${window.location.origin}/api/payment-webhook`],
        customData: {
          reservationId: orderData.reservationId,
        },
      });

      if (response.code === "SUCCESS") {
        // Verify payment
        const verificationResponse = await apiRequest("POST", "/api/verify-payment", {
          orderId: orderData.orderId,
          paymentId: response.paymentId,
          amount: amount,
        });

        const verificationData = await verificationResponse.json();

        // 2) 성공 시 주문 정보를 sessionStorage 저장 후 성공 페이지로 이동
        if (verificationData.success) {
          const orderSummary = {
            orderId: orderData.orderId,
            paymentId: response.paymentId,
            unitNumber: unit.unitNumber,
            unitSize: unit.size,
            period,
            daysBetween,
            amount,
            customer: customerInfo,
          };
          sessionStorage.setItem("lastOrder", JSON.stringify(orderSummary));

          toast({
            title: "결제 성공",
            description: "예약이 완료되었습니다!",
          });

          setLocation(`/payment/success?paymentId=${response.paymentId}`);
        } else {
          throw new Error("결제 검증 실패");
        }
      } else {
        throw new Error(response.message || "결제 실패");
      }
    } catch (error: any) {
      toast({
        title: "결제 오류",
        description: error.message || "결제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">

      <Button 
        onClick={handlePayment}
        disabled={isProcessing}
        className="w-full bg-gradient-to-r from-primary/80 to-primary/60 hover:opacity-90 text-white/90 backdrop-blur-md py-3 rounded-lg font-medium flex items-center justify-center gap-2"
      >
        {isProcessing ? (
          "결제 중..."
        ) : (
          <>
            <CreditCard className="w-5 h-5" /> {`${amount.toLocaleString()}원 결제하기`}
          </>
        )}
      </Button>
    </div>
  );
}

export default function Checkout() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [userInfo, setUserInfo] = useState({
    name: "",
    email: "",
    phone: "",
  });

  // Parse URL parameters from window.location.search to ensure query string is captured
  const params = new URLSearchParams(window.location.search);
  const unitId = params.get("unitId");
  const period = params.get("period") || "monthly";

  // 시작·종료 날짜 파라미터 추출 (일 단위 결제 시 사용)
  const startDateParam = params.get("startDate");
  const endDateParam = params.get("endDate");

  // 두 날짜 사이의 일수(양 끝 포함) 계산 함수 – 유효하지 않으면 0 반환
  const getDaysBetween = (start: string | null, end: string | null): number => {
    if (!start || !end) return 0;
    const startDate = new Date(start);
    const endDate = new Date(end);
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return 0;
    // 차이 +1(당일 포함)
    return Math.floor((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
  };

  const daysBetween = getDaysBetween(startDateParam, endDateParam);

  const { data: unit, isLoading } = useQuery<StorageUnit>({
    queryKey: ["/api/storage-units", unitId],
    enabled: !!unitId,
  });

  // 기존 amount 계산 함수에 일 단위 추가
  const getAmount = (unit: StorageUnit | undefined, period: string) => {
    if (!unit) return 0;
    switch (period) {
      case "monthly":
        return Number(unit.monthlyPrice) || 0;
      case "quarterly":
        return Number(unit.quarterlyPrice) || 0;
      case "yearly":
        return Number(unit.yearlyPrice) || 0;
      case "daily": {
        // 우선 dailyPrice 있으면 사용, 없으면 월 요금을 30으로 나눔
        const dailyPrice = unit.dailyPrice !== undefined && unit.dailyPrice !== null
          ? Number(unit.dailyPrice)
          : (Number(unit.monthlyPrice) || 0) / 30;
        return Math.round(dailyPrice * daysBetween / 100) * 100; // 100원 단위 반올림
      }
      default:
        return 0;
    }
  };

  // 2) 총 금액 계산 적용
  const amount = getAmount(unit, period);

  // Load PortOne SDK
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://cdn.portone.io/v2/browser-sdk.js";
    script.async = true;
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  const handleUserInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInfo.name || !userInfo.email) {
      toast({
        title: "입력 오류",
        description: "이름과 이메일을 입력해주세요.",
        variant: "destructive",
      });
      return;
    }
    setShowPaymentForm(true);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!unit) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <p className="text-gray-400">저장소 정보를 찾을 수 없습니다.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <section className="px-4 py-6">
        <Button 
          variant="outline" 
          size="sm" 
          className="mb-4 flex items-center gap-1 bg-gradient-to-r from-gray-700/80 to-gray-600/60 backdrop-blur-sm hover:opacity-90"
          onClick={() => {
            if (window.history.length > 1) {
              window.history.back();
            } else {
              navigate(-1 as any);
            }
          }}
        >
          <ArrowLeft className="w-4 h-4" /> 뒤로가기
        </Button>
        <h1 className="text-2xl font-bold mb-6">결제하기</h1>

        {/* Order Summary */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-lg">주문 정보</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span>로커 번호</span>
                <span className="font-medium">{unit.unitNumber || `#${unit.id}`}</span>
              </div>
              <div className="flex justify-between">
                <span>보관함 크기</span>
                <span className="font-medium">{unit.size}</span>
              </div>
              <div className="flex justify-between">
                <span>보관함 규격</span>
                <span className="font-medium">{unit.dimensions.replace("x", " × ")}cm</span>
              </div>
              <div className="flex justify-between">
                <span>구독 기간</span>
                <span className="font-medium">
                  {period === "daily"
                    ? `${daysBetween}일`
                    : period === "monthly"
                    ? "1개월"
                    : period === "quarterly"
                    ? "3개월"
                    : "12개월"}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-bold">
                <span>총 금액</span>
                <span className="text-primary">{amount.toLocaleString()}원</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* User Information Form */}
        {!showPaymentForm && (
          <Card className="bg-gray-800 border-gray-700 mb-6">
            <CardHeader>
              <CardTitle className="text-lg">예약자 정보</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleUserInfoSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="name">이름 *</Label>
                  <Input
                    id="name"
                    type="text"
                    value={userInfo.name}
                    onChange={(e) => setUserInfo({ ...userInfo, name: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">이메일 *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={userInfo.email}
                    onChange={(e) => setUserInfo({ ...userInfo, email: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">전화번호</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={userInfo.phone}
                    onChange={(e) => setUserInfo({ ...userInfo, phone: e.target.value })}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <Button type="submit" className="w-full bg-gradient-to-r from-primary/80 to-primary/60 hover:opacity-90 text-white/90 backdrop-blur-md flex items-center justify-center gap-2">
                  <FileEdit className="w-4 h-4" /> 결제 정보 입력하기
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Payment Form */}
        {showPaymentForm && (
          <PaymentForm 
            unit={unit} 
            period={period} 
            amount={amount} 
            customerInfo={userInfo}
            daysBetween={daysBetween}
            startDate={startDateParam}
            endDate={endDateParam}
          />
        )}
      </section>
    </div>
  );
}
