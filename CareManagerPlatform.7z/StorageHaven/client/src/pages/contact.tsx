import { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Phone,
  Mail,
  MessageSquare,
  Clock,
  ChevronUp,
  ChevronDown,
} from "lucide-react";

export default function Contact() {
  // 문의 폼을 제거했으므로 toast 사용 코드도 삭제했습니다.
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"general" | "storage">("general");
  // 문의 폼 제거로 상태 관리 불필요

  /* FAQ 데이터 – 결제 & 공유창고 */
  const generalFaqs = [
    {
      id: "payment_flow",
      question: "결제 프로세스",
      answer:
        "savebox는 포트원(PortOne) 결제 게이트웨이를 사용합니다. 예약하기 → 체크아웃 페이지에서 금액 확인 → 결제 요청 시 PortOne 카드 결제창이 열립니다. ",
    },
    {
      id: "payment_methods",
      question: "지원 결제 수단",
      answer:
        "국내 신용·체크카드, 카카오페이·네이버페이 등 간편결제, 휴대폰 소액결제를 지원합니다. 해외 카드 및 무통장입금도 지원합니다.",
    },
    {
      id: "receipt",
      question: "영수증 및 세금계산서 발급",
      answer:
        "결제 완료 후 PortOne 전자 영수증이 이메일로 전송됩니다. 세금계산서가 필요하시면 support@savebox.kr 로 사업자 정보를 보내주세요.",
    },
    {
      id: "refund_policy",
      question: "환불 정책",
      answer:
        "결제 후 24시간 이내 취소 시 전액 환불되며, 이후에는 이용약관의 환불 규정을 따릅니다. 마이페이지 또는 고객센터를 통해 환불을 신청할 수 있습니다.",
    },
  ];

  const storageFaqs = [
    {
      id: "period",
      question: "최소 보관기간 및 일일보관",
      answer:
        "모든 서비스의 최소 이용 기간은 1개월이며, 1sqft(1/12평) 기준 일일 20,000원의 기본요금이 적용됩니다.",
    },
    {
      id: "termination",
      question: "서비스 이용종료/취소 절차",
      answer:
        "이용 종료 7일 전 종료 의사를 전달하고 창고를 비운 사진을 제출해야 정상 종료 처리됩니다.",
    },
    {
      id: "environment",
      question: "창고 환경",
      answer:
        "24시간 CCTV와 대용량 제습기로 안심 보관 환경을 제공합니다.",
    },
  ];

  const faqData = activeTab === "general" ? generalFaqs : storageFaqs;

  const toggleFaq = (id: string) => {
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  // 문의 폼 제거로 handleSubmit 함수 삭제

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Hero */}
      <section className="bg-gradient-to-r from-primary/30 to-primary/10 py-16 text-center px-4">
        <h1 className="text-3xl font-bold mb-4">도움이 필요하신가요?</h1>
        <p className="text-gray-300 max-w-2xl mx-auto">
          자주 묻는 질문을 먼저 확인하시면 더 빠르게 답을 찾으실 수 있습니다.
        </p>
      </section>

      {/* 연락 수단 */}
      <section className="px-4 py-10 max-w-4xl mx-auto grid gap-6 sm:grid-cols-3">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 flex flex-col items-center space-y-2">
            <Phone className="text-primary w-6 h-6" />
            <p className="font-medium">전화문의</p>
            <p className="text-sm text-gray-400">02-555-5155</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 flex flex-col items-center space-y-2">
            <Mail className="text-primary w-6 h-6" />
            <p className="font-medium">이메일 문의</p>
            <p className="text-sm text-gray-400">support@savebox.kr</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6 flex flex-col items-center space-y-2">
            <MessageSquare className="text-primary w-6 h-6" />
            <p className="font-medium">카카오톡 채널</p>
            <p className="text-sm text-gray-400">@디컴소프트</p>
          </CardContent>
        </Card>
      </section>

      {/* 상담 시간 */}
      <section className="px-4">
        <Card className="bg-gray-800 border-gray-700 max-w-md mx-auto">
          <CardContent className="p-6 flex items-center justify-center space-x-3">
            <Clock className="text-primary w-6 h-6" />
            <p className="text-sm text-gray-400">
              상담 시간 : 평일 10:00 - 18:00 (점심시간 12:00 - 13:00)
            </p>
          </CardContent>
        </Card>
      </section>

      {/* FAQ */}
      <section className="px-4 py-12 bg-gray-800/40">
        <h2 className="text-2xl font-bold text-center mb-6">자주 묻는 질문</h2>

        <div className="flex justify-center gap-2 mb-8">
          <Button
            variant={activeTab === "general" ? "default" : "outline"}
            onClick={() => setActiveTab("general")}
            className={`text-sm ${
              activeTab === "general"
                ? "bg-primary text-white"
                : "bg-gray-700 border-gray-600 text-gray-300"
            }`}
          >
            공통질문
          </Button>
          <Button
            variant={activeTab === "storage" ? "default" : "outline"}
            onClick={() => setActiveTab("storage")}
            className={`text-sm ${
              activeTab === "storage"
                ? "bg-primary text-white"
                : "bg-gray-700 border-gray-600 text-gray-300"
            }`}
          >
            셀프 공유창고
          </Button>
        </div>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqData.map((faq) => (
            <div
              key={faq.id}
              className="bg-gray-800 border border-gray-700 rounded-lg"
            >
              <button
                onClick={() => toggleFaq(faq.id)}
                className="w-full p-4 flex items-center justify-between text-left"
              >
                <span className="text-primary font-medium">{faq.question}</span>
                {expandedFaq === faq.id ? (
                  <ChevronUp className="text-gray-400 w-4 h-4" />
                ) : (
                  <ChevronDown className="text-gray-400 w-4 h-4" />
                )}
              </button>
              {expandedFaq === faq.id && (
                <div className="px-4 pb-4 text-sm text-gray-300">
                  {faq.answer}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* 문의 폼 삭제 완료 */}
    </div>
  );
}
