import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import LocationFinder from "@/pages/location-finder";
import StorageDetails from "@/pages/storage-details";
import Checkout from "@/pages/checkout";
import Contact from "@/pages/contact";
import Franchise from "@/pages/franchise";
import Header from "@/components/layout/header";
import Navigation from "@/components/layout/navigation";
import Footer from "@/components/layout/footer";
import { LanguageProvider } from "@/contexts/language-context";
import { AuthProvider } from "@/contexts/auth-context";
import LoginPage from "@/pages/login";
import RegisterPage from "@/pages/register";
import KakaoCallback from "@/pages/oauth/kakao/callback";
import ProfilePage from "@/pages/profile";
import FranchiseDashboardPage from "@/pages/franchise-dashboard";
import PaymentSuccess from "@/pages/payment/success";
import PaymentFailure from "@/pages/payment/failure";
import PWAInstaller from "@/components/PWAInstaller";

function Router() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Header />
      <Navigation />
      <main>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/locations" component={LocationFinder} />
          <Route path="/storage/:locationId" component={StorageDetails} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/payment/success" component={PaymentSuccess} />
          <Route path="/payment/failure" component={PaymentFailure} />
          <Route path="/payment" component={Checkout} />
          <Route path="/contact" component={Contact} />
          <Route path="/franchise" component={Franchise} />
          <Route path="/login" component={LoginPage} />
          <Route path="/register" component={RegisterPage} />
          <Route path="/oauth/kakao/callback" component={KakaoCallback} />
          <Route path="/profile" component={ProfilePage} />
          <Route path="/profile/:tab" component={ProfilePage} />
          <Route path="/franchise-dashboard" component={FranchiseDashboardPage} />
          <Route path="/franchise-dashboard/:tab" component={FranchiseDashboardPage} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
      <PWAInstaller />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <LanguageProvider>
          <AuthProvider>
            <div className="dark">
              <Toaster />
              <Router />
            </div>
          </AuthProvider>
        </LanguageProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
