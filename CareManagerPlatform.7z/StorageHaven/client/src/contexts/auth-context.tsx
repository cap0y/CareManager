import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { userApi } from '@/services/api';

// Firebase 관련 임포트
import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  onAuthStateChanged,
  updateProfile,
  User as FirebaseUser
} from 'firebase/auth';

// 카카오 SDK 타입 정의
declare global {
  interface Window {
    Kakao: {
      init: (key: string) => void;
      isInitialized: () => boolean;
      Auth: {
        authorize: (options: { 
          redirectUri: string;
          throughTalk?: boolean;
        }) => void;
      };
      API: {
        request: <T>(options: {
          url: string;
          success: (response: T) => void;
          fail: (error: any) => void;
        }) => void;
      };
    };
  }
}

// Firebase 설정 - 환경 변수 대신 직접 값을 설정
const firebaseConfig = {
  apiKey: "AIzaSyBq0TweBfCPGRcJot7JlJHXRNPnJ1WHjcM",
  authDomain: "savebox-e1d0a.firebaseapp.com",
  projectId: "savebox-e1d0a",
  storageBucket: "savebox-e1d0a.appspot.com",
  messagingSenderId: "112254418557588997901",
  appId: "1:112254418557588997901:web:abcdef1234567890abcdef"
};

// 카카오 설정
const KAKAO_CLIENT_ID = "4d53287fcaa83a038163adf3b057b802";
const KAKAO_REDIRECT_URI = `${window.location.origin}/oauth/kakao/callback`;

// Firebase 초기화
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

// 카카오 초기화
const initializeKakao = () => {
  // 카카오 SDK가 로드되었는지 확인
  if (window.Kakao && !window.Kakao.isInitialized()) {
    window.Kakao.init(KAKAO_CLIENT_ID);
  }
};

// 슈퍼 관리자 이메일 설정
const SUPER_ADMIN_EMAIL = "decom2soft@gmail.com";

export type UserType = 'user' | 'franchise' | 'admin';

interface User {
  id: string;
  username: string;
  email: string;
  displayName: string;
  photoURL?: string;
  provider?: 'email' | 'google' | 'kakao';
  userType: UserType;
  isApproved?: boolean; // 가맹점 승인 여부
  backendId?: number; // 백엔드에서 할당받은 고유 ID
  partnerId?: string; // 포트원 파트너 ID
}

interface LoginCredentials {
  email: string;
  password: string;
}

interface RegisterCredentials {
  email: string;
  password: string;
  username: string;
  displayName?: string;
  userType?: UserType;
  franchiseInfo?: {
    name: string;
    address: string;
    phone: string;
    isApproved: boolean;
  };
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (credentials: RegisterCredentials) => Promise<void>;
  googleLogin: () => Promise<void>;
  kakaoLogin: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Firebase 사용자를 앱 사용자로 변환하는 함수
const mapFirebaseUserToUser = (firebaseUser: FirebaseUser, provider?: 'email' | 'google' | 'kakao', additionalData?: any): User => {
  // 이메일이 슈퍼 관리자 이메일인지 확인
  const isAdminEmail = firebaseUser.email === SUPER_ADMIN_EMAIL;
  
  // 디버깅: additionalData 로그
  console.log("Additional data for user mapping:", additionalData);
  
  // 로컬 스토리지에서 기존 사용자 정보 확인
  let existingUserData: User | null = null;
  try {
    const localUser = localStorage.getItem('auth_user');
    if (localUser) {
      existingUserData = JSON.parse(localUser) as User;
    }
  } catch (e) {
    console.error("로컬 스토리지 사용자 정보 파싱 오류:", e);
  }
  
  // 사용자 타입 결정 로직
  let userType: UserType = 'user';
  
  if (isAdminEmail) {
    userType = 'admin';
  } else if (additionalData?.userType) {
    // 백엔드 데이터에 userType이 있으면 사용
    userType = additionalData.userType;
  } else if (additionalData?.franchiseInfo) {
    // franchiseInfo가 있으면 가맹점 회원
    userType = 'franchise';
  } else if (existingUserData?.userType) {
    // 로컬 스토리지에 저장된 사용자 타입이 있으면 사용
    userType = existingUserData.userType;
  }
  
  // 승인 여부 확인
  const isApproved = additionalData?.isApproved ?? existingUserData?.isApproved ?? false;
  
  return {
    id: firebaseUser.uid,
    username: firebaseUser.email?.split('@')[0] || '',
    email: firebaseUser.email || '',
    displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || '',
    photoURL: firebaseUser.photoURL || undefined,
    provider: provider || (firebaseUser.providerData[0]?.providerId === 'google.com' ? 'google' : 'email'),
    userType: userType,
    isApproved: isApproved,
    backendId: additionalData?.id || existingUserData?.backendId,
    partnerId: additionalData?.partnerId || existingUserData?.partnerId
  };
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // 초기 로드 시 로그인 상태 확인 및 카카오 초기화
  useEffect(() => {
    // 카카오 SDK 로드
    const loadKakaoSDK = () => {
      const script = document.createElement('script');
      script.src = 'https://developers.kakao.com/sdk/js/kakao.js';
      script.async = true;
      script.onload = initializeKakao;
      document.body.appendChild(script);
    };

    loadKakaoSDK();

    // Firebase 인증 상태 관찰
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        (async () => {
          // 먼저 로컬 스토리지에서 기존 사용자 정보를 가져옴
          let existingUserData: User | null = null;
          const localUser = localStorage.getItem('auth_user');
          if (localUser) {
            try {
              existingUserData = JSON.parse(localUser) as User;
            } catch (e) {
              console.error("로컬 스토리지 사용자 정보 파싱 오류:", e);
            }
          }

          try {
            console.log(`[DEBUG] Firebase UID로 사용자 정보 요청: ${firebaseUser.uid}`);
            const { data } = await userApi.getUserByFirebaseUid(
              firebaseUser.uid,
              firebaseUser.email || undefined,
              firebaseUser.displayName || undefined
            );
            console.log("[DEBUG] 백엔드 응답 데이터:", data); // 디버깅용 로그 추가
            
            // 응답 구조 확인
            let userData = data?.user || data;
            
            if (userData) {
              // 서버에서 사용자 데이터를 가져온 경우
              const mappedUser = mapFirebaseUserToUser(firebaseUser, undefined, userData);
              
              // 디버깅: 사용자 타입 로그
              console.log("[DEBUG] 매핑된 사용자 정보:", mappedUser);
              
              setUser(mappedUser);
              
              // 로컬 스토리지에 업데이트된 정보 저장
              localStorage.setItem('auth_user', JSON.stringify(mappedUser));
            } else if (existingUserData) {
              // 서버에서 데이터를 가져오지 못했지만 로컬에 정보가 있는 경우
              // Firebase 사용자 정보만 업데이트하고 기존 userType 등은 유지
              const updatedUser = {
                ...existingUserData,
                id: firebaseUser.uid,
                email: firebaseUser.email || existingUserData.email,
                displayName: firebaseUser.displayName || existingUserData.displayName,
                photoURL: firebaseUser.photoURL || existingUserData.photoURL
              };
              setUser(updatedUser);
              localStorage.setItem('auth_user', JSON.stringify(updatedUser));
            } else {
              // 서버에 데이터가 없고 로컬에도 없는 경우 기본 매핑
              const mappedUser = mapFirebaseUserToUser(firebaseUser);
              setUser(mappedUser);
              localStorage.setItem('auth_user', JSON.stringify(mappedUser));
            }
          } catch (e) {
            console.error("API 호출 오류:", e);
            
            if (existingUserData) {
              // API 오류 발생했지만 로컬에 정보가 있는 경우, 기존 정보 유지
              const updatedUser = {
                ...existingUserData,
                id: firebaseUser.uid,
                email: firebaseUser.email || existingUserData.email,
                displayName: firebaseUser.displayName || existingUserData.displayName,
                photoURL: firebaseUser.photoURL || existingUserData.photoURL
              };
              setUser(updatedUser);
              localStorage.setItem('auth_user', JSON.stringify(updatedUser));
            } else {
              // API 호출 오류시 기본 매핑
              const mappedUser = mapFirebaseUserToUser(firebaseUser);
              setUser(mappedUser);
              localStorage.setItem('auth_user', JSON.stringify(mappedUser));
            }
          }
        })();
      } else {
        // Firebase에 로그인되어 있지 않은 경우 로컬 스토리지 확인
        const localUser = localStorage.getItem('auth_user');
        if (localUser) {
          try {
            const parsedUser = JSON.parse(localUser);
            setUser(parsedUser as User);
          } catch (e) {
            localStorage.removeItem('auth_user');
            setUser(null);
          }
        } else {
          setUser(null);
        }
      }
      setIsLoading(false);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // 이메일 로그인
  const login = async (credentials: LoginCredentials) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { user: firebaseUser } = await signInWithEmailAndPassword(
        auth, 
        credentials.email, 
        credentials.password
      );
      
      // 먼저 로컬 스토리지에서 기존 사용자 정보를 가져옴
      let existingUserData: User | null = null;
      const localUser = localStorage.getItem('auth_user');
      if (localUser) {
        try {
          existingUserData = JSON.parse(localUser) as User;
        } catch (e) {
          console.error("로컬 스토리지 사용자 정보 파싱 오류:", e);
        }
      }
      
      // 백엔드에서 사용자 정보 가져오기 시도
      try {
        console.log(`[DEBUG] 로그인 - Firebase UID로 사용자 정보 요청: ${firebaseUser.uid}`);
        const { data } = await userApi.getUserByFirebaseUid(
          firebaseUser.uid,
          firebaseUser.email || undefined,
          firebaseUser.displayName || undefined
        );
        console.log("[DEBUG] 로그인 - 백엔드 응답 데이터:", data);
        
        let userData = data?.user || data;
        
        if (userData) {
          // 백엔드 데이터가 있는 경우
          const mappedUser = mapFirebaseUserToUser(firebaseUser, 'email', userData);
          console.log("[DEBUG] 로그인 - 매핑된 사용자 정보:", mappedUser);
          
          setUser(mappedUser);
          localStorage.setItem('auth_user', JSON.stringify(mappedUser));
          return;
        }
      } catch (apiError) {
        console.error('[ERROR] 백엔드 사용자 정보 조회 오류:', apiError);
        // 백엔드 조회 실패해도 기본 로그인은 허용
      }
      
      // 백엔드 조회 실패 또는 데이터 없는 경우
      if (existingUserData && existingUserData.email === credentials.email) {
        // 로컬에 저장된 정보가 있고 이메일이 일치하면 기존 정보 유지
        const updatedUser = {
          ...existingUserData,
          id: firebaseUser.uid,
          email: firebaseUser.email || existingUserData.email,
          displayName: firebaseUser.displayName || existingUserData.displayName,
          photoURL: firebaseUser.photoURL || existingUserData.photoURL
        };
        setUser(updatedUser);
        localStorage.setItem('auth_user', JSON.stringify(updatedUser));
      } else {
        // 로컬에 정보가 없거나 이메일이 다른 경우 기본 매핑
        const mappedUser = mapFirebaseUserToUser(firebaseUser, 'email');
        setUser(mappedUser);
        localStorage.setItem('auth_user', JSON.stringify(mappedUser));
      }
    } catch (error: any) {
      console.error('로그인 오류:', error);
      
      if (error.code === 'auth/user-not-found' || error.code === 'auth/wrong-password') {
        setError('이메일 또는 비밀번호가 올바르지 않습니다.');
      } else if (error.code === 'auth/too-many-requests') {
        setError('너무 많은 로그인 시도가 있었습니다. 잠시 후 다시 시도해주세요.');
      } else {
        setError('로그인 중 오류가 발생했습니다.');
      }
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // 회원가입
  const register = async (credentials: RegisterCredentials) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { user: firebaseUser } = await createUserWithEmailAndPassword(
        auth, 
        credentials.email, 
        credentials.password
      );
      
      // 사용자 프로필 업데이트
      await updateProfile(firebaseUser, {
        displayName: credentials.displayName || credentials.username
      });
      
      // 사용자 타입 설정 (슈퍼 관리자 이메일인 경우 무조건 admin으로 설정)
      const userType = credentials.email === SUPER_ADMIN_EMAIL ? 'admin' : (credentials.userType || 'user');
      
      // 가맹점 회원 또는 관리자인 경우 PostgreSQL에 저장
      if (userType === 'franchise' || userType === 'admin') {
        try {
          // API 서비스를 통해 사용자 정보 저장
          await userApi.createUser({
            firebaseUid: firebaseUser.uid,
            username: credentials.username,
            email: credentials.email,
            password: '**hashed**', // 실제로는 해시된 비밀번호를 저장하지 않음 (Firebase에서 관리)
            displayName: credentials.displayName || credentials.username,
            userType: userType,
            isApproved: userType === 'admin', // 관리자는 자동 승인, 가맹점은 승인 필요
            franchiseInfo: credentials.franchiseInfo,
          });
        } catch (dbError) {
          console.error('데이터베이스 저장 오류:', dbError);
          // DB 저장 실패해도 Firebase 인증은 유지
        }
      }
      
      const mappedUser: User = {
        id: firebaseUser.uid,
        username: credentials.username,
        email: credentials.email,
        displayName: credentials.displayName || credentials.username,
        photoURL: firebaseUser.photoURL || undefined,
        provider: 'email',
        userType: userType,
        isApproved: userType === 'admin' ? true : userType === 'franchise' ? false : undefined
      };
      
      setUser(mappedUser);
      
      // 로컬 스토리지에 사용자 정보 저장
      localStorage.setItem('auth_user', JSON.stringify(mappedUser));
    } catch (error: any) {
      console.error('회원가입 오류:', error);
      
      if (error.code === 'auth/email-already-in-use') {
        setError('이미 사용 중인 이메일입니다.');
      } else if (error.code === 'auth/weak-password') {
        setError('비밀번호가 너무 약합니다.');
      } else if (error.code === 'auth/invalid-email') {
        setError('유효하지 않은 이메일 형식입니다.');
      } else {
        setError('회원가입 중 오류가 발생했습니다.');
      }
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // 구글 로그인
  const googleLogin = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const mappedUser = mapFirebaseUserToUser(result.user, 'google');
      
      // 구글 로그인 시에도 슈퍼 관리자 이메일 확인
      if (result.user.email === SUPER_ADMIN_EMAIL) {
        mappedUser.userType = 'admin';
        mappedUser.isApproved = true;
      }
      
      setUser(mappedUser);
    } catch (error: any) {
      console.error('구글 로그인 오류:', error);
      
      if (error.code === 'auth/popup-closed-by-user') {
        setError('로그인 창이 닫혔습니다. 다시 시도해주세요.');
      } else {
        setError('구글 로그인 중 오류가 발생했습니다.');
      }
      
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // 카카오 로그인
  const kakaoLogin = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // 카카오 SDK가 로드되었는지 확인
      if (!window.Kakao || !window.Kakao.isInitialized()) {
        initializeKakao();
      }
      
      // 카카오 로그인 창 열기 (웹 방식으로만 로그인)
      window.Kakao.Auth.authorize({
        redirectUri: KAKAO_REDIRECT_URI,
        throughTalk: false // 카카오톡 앱을 통한 로그인 비활성화
      });
      
      // 참고: 카카오 로그인은 리다이렉션 방식으로 작동하므로
      // 콜백 페이지에서 처리 로직이 필요합니다.
    } catch (error: any) {
      console.error('카카오 로그인 오류:', error);
      setError('카카오 로그인 중 오류가 발생했습니다.');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // 로그아웃
  const logout = async () => {
    setIsLoading(true);
    
    try {
      // Firebase 로그아웃
      await signOut(auth);
      
      // 로컬 스토리지에서 사용자 정보 삭제
      localStorage.removeItem('auth_user');
      
      setUser(null);
    } catch (error: any) {
      console.error('로그아웃 오류:', error);
      setError('로그아웃 중 오류가 발생했습니다.');
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    error,
    login,
    register,
    googleLogin,
    kakaoLogin,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    // 개발 중 HMR 로 인한 이중 번들 문제 대응 – fallback 값 반환
    console.warn('useAuth called outside AuthProvider');
    return {
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
      login: async () => {},
      register: async () => {},
      googleLogin: async () => {},
      kakaoLogin: async () => {},
      logout: async () => {},
    } as any;
  }
  return context;
} 