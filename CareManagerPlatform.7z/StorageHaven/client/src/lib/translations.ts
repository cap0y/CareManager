// 다국어 번역을 위한 공통 파일
import { Language } from '@/contexts/language-context';

// 공통 번역
export const commonTranslations = {
  ko: {
    // 공통 UI 요소
    appName: "SAVEBOX",
    loading: "로딩 중...",
    notFound: "찾을 수 없습니다",
    error: "오류가 발생했습니다",
    
    // 네비게이션
    home: "홈",
    locations: "지점 찾기",
    myAccount: "내 계정",
    login: "로그인",
    logout: "로그아웃",
    profile: "프로필",
    contact: "고객센터",
    franchise: "가맹문의",
    
    // 버튼
    search: "검색",
    findNearby: "내 주변 찾기",
    viewAll: "모두 보기",
    reserve: "예약하기",
    
    // 홈페이지
    selfStorage: "셀프 공유창고",
    nearbyStorage: "우리집과 가까운 24시간 무인 개별 보관함",
    searchingLocation: "위치 검색 중...",
    findNearbyStorage: "내 주변 공유창고 찾기",
    viewAllStorage: "모든 공유창고 보기",
    nearbyLocations: "주변 지점",
    popularLocations: "인기 지점",
    howToUse: "이용방법",
    facilityFeatures: "시설 특징",
    noLocations: "등록된 지점이 없습니다.",
    noUnits: "사용 가능한 보관함이 없습니다.",
    
    // 위치 찾기
    selectLocation: "지점 선택하기",
    myLocation: "내 위치",
    searching: "검색 중...",
    locationTitle: "위치",
    priceInfo: "가격 정보",
    
    // 시설 특징
    openAllDay: "24시간 이용 가능",
    security: "보안 시설",
    cctv: "CCTV 관제",
    parking: "주차 가능",
    temperature: "냉난방 시설",
    storage: "물품 보관함",
    
    // 이용 방법
    step1Title: "지점 선택하기",
    step1Desc: "원하는 지역의 지점을 선택하세요.",
    step2Title: "보관함 크기 선택",
    step2Desc: "필요에 맞는 보관함 크기를 선택하세요.",
    step3Title: "결제 및 예약",
    step3Desc: "간편한 온라인 결제로 바로 예약하세요.",
    
    // 예약 관련
    monthly: "월간",
    quarterly: "3개월",
    yearly: "12개월",
    customPeriod: "기간",
    dailyPrice: "일 이용료",
    monthlyPrice: "월 이용료",
    quarterlyPrice: "3개월 이용료",
    yearlyPrice: "12개월 이용료",
    totalPrice: "총 이용료",
    days: "일",
    selectDates: "날짜 선택"
  },
  
  en: {
    // 공통 UI 요소
    appName: "SAVEBOX",
    loading: "Loading...",
    notFound: "Not Found",
    error: "An error occurred",
    
    // 네비게이션
    home: "Home",
    locations: "Find Locations",
    myAccount: "My Account",
    login: "Login",
    logout: "Logout",
    profile: "Profile",
    contact: "Contact",
    franchise: "Franchise Inquiry",
    
    // 버튼
    search: "Search",
    findNearby: "Find Nearby",
    viewAll: "View All",
    reserve: "Reserve",
    
    // 홈페이지
    selfStorage: "Self Storage",
    nearbyStorage: "24/7 Unmanned Individual Storage Near Your Home",
    searchingLocation: "Searching location...",
    findNearbyStorage: "Find Storage Near Me",
    viewAllStorage: "View All Storage Locations",
    nearbyLocations: "Nearby Locations",
    popularLocations: "Popular Locations",
    howToUse: "How to Use",
    facilityFeatures: "Facility Features",
    noLocations: "No locations available.",
    noUnits: "No storage units available.",
    
    // 위치 찾기
    selectLocation: "Select Location",
    myLocation: "My Location",
    searching: "Searching...",
    locationTitle: "Location",
    priceInfo: "Price Information",
    
    // 시설 특징
    openAllDay: "Open 24 Hours",
    security: "Security System",
    cctv: "CCTV Monitoring",
    parking: "Parking Available",
    temperature: "Climate Control",
    storage: "Storage Units",
    
    // 이용 방법
    step1Title: "Select a Location",
    step1Desc: "Choose a location in your desired area.",
    step2Title: "Select Storage Size",
    step2Desc: "Choose a storage size that fits your needs.",
    step3Title: "Payment and Reservation",
    step3Desc: "Make a reservation with easy online payment.",
    
    // 예약 관련
    monthly: "Monthly Plan",
    quarterly: "Quarterly Plan",
    yearly: "Yearly Plan",
    customPeriod: "Custom Period",
    dailyPrice: "Daily Price",
    monthlyPrice: "Monthly Price",
    quarterlyPrice: "Quarterly Price",
    yearlyPrice: "Yearly Price",
    totalPrice: "Total Price",
    days: "days",
    selectDates: "Select Dates"
  },
  
  ja: {
    // 공통 UI 요소
    appName: "SAVEBOX",
    loading: "読み込み中...",
    notFound: "見つかりません",
    error: "エラーが発生しました",
    
    // 네비게이션
    home: "ホーム",
    locations: "拠点検索",
    myAccount: "マイアカウント",
    login: "ログイン",
    logout: "ログアウト",
    profile: "プロフィール",
    contact: "お問い合わせ",
    franchise: "加盟店問い合わせ",
    
    // 버튼
    search: "検索",
    findNearby: "近くを検索",
    viewAll: "すべて表示",
    reserve: "予約する",
    
    // 홈페이지
    selfStorage: "セルフストレージ",
    nearbyStorage: "自宅の近くにある24時間無人個別保管庫",
    searchingLocation: "位置検索中...",
    findNearbyStorage: "近くのストレージを検索",
    viewAllStorage: "すべてのストレージ拠点を表示",
    nearbyLocations: "近くの拠点",
    popularLocations: "人気の拠点",
    howToUse: "利用方法",
    facilityFeatures: "施設の特徴",
    noLocations: "登録された拠点はありません。",
    noUnits: "利用可能な保管ユニットがありません。",
    
    // 위치 찾기
    selectLocation: "拠点を選択",
    myLocation: "現在位置",
    searching: "検索中...",
    locationTitle: "位置",
    priceInfo: "料金情報",
    
    // 시설 특징
    openAllDay: "24時間利用可能",
    security: "セキュリティシステム",
    cctv: "CCTV監視",
    parking: "駐車場あり",
    temperature: "空調設備",
    storage: "収納ユニット",
    
    // 이용 방법
    step1Title: "拠点を選択",
    step1Desc: "希望するエリアの拠点を選択してください。",
    step2Title: "保管サイズを選択",
    step2Desc: "必要に合った保管サイズを選択してください。",
    step3Title: "決済と予約",
    step3Desc: "簡単なオンライン決済ですぐに予約できます。",
    
    // 예약 관련
    monthly: "月間プラン",
    quarterly: "3ヶ月プラン",
    yearly: "12ヶ月プラン",
    customPeriod: "期間指定",
    dailyPrice: "日料金",
    monthlyPrice: "月額料金",
    quarterlyPrice: "3ヶ月料金",
    yearlyPrice: "年間料金",
    totalPrice: "合計料金",
    days: "日",
    selectDates: "日付選択"
  },
  
  zh: {
    // 공통 UI 요소
    appName: "SAVEBOX",
    loading: "加载中...",
    notFound: "未找到",
    error: "发生错误",
    
    // 네비게이션
    home: "首页",
    locations: "查找位置",
    myAccount: "我的账户",
    login: "登录",
    logout: "退出",
    profile: "个人资料",
    contact: "联系我们",
    franchise: "加盟咨询",
    
    // 버튼
    search: "搜索",
    findNearby: "查找附近",
    viewAll: "查看全部",
    reserve: "预订",
    
    // 홈페이지
    selfStorage: "自助存储",
    nearbyStorage: "离家近的24/7无人个人存储",
    searchingLocation: "正在搜索位置...",
    findNearbyStorage: "查找附近存储",
    viewAllStorage: "查看所有存储位置",
    nearbyLocations: "附近位置",
    popularLocations: "热门位置",
    howToUse: "使用方法",
    facilityFeatures: "设施特点",
    noLocations: "没有可用的位置。",
    noUnits: "没有可用的存储单元。",
    
    // 위치 찾기
    selectLocation: "选择位置",
    myLocation: "我的位置",
    searching: "搜索中...",
    locationTitle: "位置",
    priceInfo: "价格信息",
    
    // 시설 특징
    openAllDay: "24小时开放",
    security: "安全系统",
    cctv: "CCTV监控",
    parking: "可停车",
    temperature: "温控",
    storage: "存储单元",
    
    // 이용 방법
    step1Title: "选择位置",
    step1Desc: "选择您所需区域的位置。",
    step2Title: "选择存储大小",
    step2Desc: "选择适合您需求的存储大小。",
    step3Title: "支付和预订",
    step3Desc: "通过简单的在线支付立即预订。",
    
    // 예약 관련
    monthly: "月计划",
    quarterly: "季度计划",
    yearly: "年计划",
    customPeriod: "自定义期间",
    dailyPrice: "日费用",
    monthlyPrice: "月费用",
    quarterlyPrice: "季度费用",
    yearlyPrice: "年费用",
    totalPrice: "总费用",
    days: "天",
    selectDates: "选择日期"
  }
};

// 스토리지 상세 페이지 번역
export const storageDetailsTranslations = {
  ko: {
    title: "고대역 서초동 공유창고",
    subtitle: "Seocho Self storage",
    description: "서초구 고대역 근첨단물류센터,문서보관,침실보관,옷보관이 가능한 셀프공유창고 입니다.",
    address: "서울시 서초구 서초중앙로 176 지하2층",
    tags: ["#개인창고", "#미니창고", "#옷보관", "#소창고", "#물품보관", "#침실보관", "#분민창고보관", "#옷보관", "#북보관", "#가구보관", "#이사보관", "#사무보관", "#셀프스토리지"],
    startDate: "시작일",
    endDate: "종료일",
    selectDates: "날짜 선택",
    days: "일",
    dailyPrice: "일 이용료",
    totalPrice: "총 이용료",
    monthlyPrice: "월 이용료",
    quarterlyPrice: "3개월 이용료",
    yearlyPrice: "12개월 이용료",
    reserve: "예약하기",
    monthly: "월간",
    quarterly: "3개월",
    yearly: "12개월",
    customPeriod: "기간",
    facilityInfo: "시설 안내",
    locationTitle: "위치",
    noUnits: "사용 가능한 보관함이 없습니다.",
    priceInfo: "가격 정보"
  },
  en: {
    title: "Godae Station Seocho Self Storage",
    subtitle: "Gangnam | Trunk room",
    description: "Advanced logistics center near Godae Station in Seocho-gu, self-storage warehouse for document storage, bedroom storage, and clothing storage.",
    address: "B2, 176 Seocho-daero, Seocho-gu, Seoul",
    tags: ["#personal storage", "#mini storage", "#clothing storage", "#small storage", "#item storage", "#bedroom storage", "#residential storage", "#clothing storage", "#book storage", "#furniture storage", "#moving storage", "#office storage", "#self storage"],
    startDate: "Start Date",
    endDate: "End Date",
    selectDates: "Select Dates",
    days: "days",
    dailyPrice: "Daily Price",
    totalPrice: "Total Price",
    monthlyPrice: "Monthly Price",
    quarterlyPrice: "Quarterly Price",
    yearlyPrice: "Yearly Price",
    reserve: "Reserve",
    monthly: "Monthly Plan",
    quarterly: "Quarterly Plan",
    yearly: "Yearly Plan",
    customPeriod: "Custom Period",
    facilityInfo: "Facility Information",
    locationTitle: "Location",
    noUnits: "No storage units available.",
    priceInfo: "Price Information"
  },
  ja: {
    title: "高大駅瑞草洞共有倉庫",
    subtitle: "江南 | トランクルーム",
    description: "瑞草区高大駅近くの先端物流センター、書類保管、寝室保管、衣類保管が可能なセルフ共有倉庫です。",
    address: "ソウル市瑞草区瑞草中央路176 地下2階",
    tags: ["#個人倉庫", "#ミニ倉庫", "#衣類保管", "#小倉庫", "#物品保管", "#寝室保管", "#住民倉庫保管", "#衣類保管", "#本保管", "#家具保管", "#引越し保管", "#事務保管", "#セルフストレージ"],
    startDate: "開始日",
    endDate: "終了日",
    selectDates: "日付選択",
    days: "日",
    dailyPrice: "日料金",
    totalPrice: "合計料金",
    monthlyPrice: "月額料金",
    quarterlyPrice: "3ヶ月料金",
    yearlyPrice: "年間料金",
    reserve: "予約する",
    monthly: "月間プラン",
    quarterly: "3ヶ月プラン",
    yearly: "12ヶ月プラン",
    customPeriod: "期間指定",
    facilityInfo: "施設案内",
    locationTitle: "位置",
    noUnits: "利用可能な保管ユニットがありません。",
    priceInfo: "料金情報"
  },
  zh: {
    title: "高大站瑞草洞共享仓库",
    subtitle: "江南 | 储物室",
    description: "瑞草区高大站附近的先进物流中心，可用于文件存储、卧室存储和衣物存储的自助共享仓库。",
    address: "首尔市瑞草区瑞草中央路176号地下2层",
    tags: ["#个人仓库", "#迷你仓库", "#衣物存储", "#小仓库", "#物品存储", "#卧室存储", "#居民仓库存储", "#衣物存储", "#书籍存储", "#家具存储", "#搬家存储", "#办公存储", "#自助存储"],
    startDate: "开始日期",
    endDate: "结束日期",
    selectDates: "选择日期",
    days: "天",
    dailyPrice: "日费用",
    totalPrice: "总费用",
    monthlyPrice: "月费用",
    quarterlyPrice: "季度费用",
    yearlyPrice: "年费用",
    reserve: "预订",
    monthly: "月计划",
    quarterly: "季度计划",
    yearly: "年计划",
    customPeriod: "自定义期间",
    facilityInfo: "设施信息",
    locationTitle: "位置",
    noUnits: "没有可用的存储单元。",
    priceInfo: "价格信息"
  }
};
