import { Link, useRoute } from "wouter";
import { Home, Search, MessageSquare, Building, User, Settings } from "lucide-react";
import { useLanguage } from "@/contexts/language-context";
import { commonTranslations } from "@/lib/translations";
import { useAuth } from "@/contexts/auth-context";

export default function Navigation() {
  const { language } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const t = commonTranslations[language];
  
  const [isHomeActive] = useRoute("/");
  const [isLocationsActive] = useRoute("/locations");
  const [isContactActive] = useRoute("/contact");
  const [isFranchiseActive] = useRoute("/franchise");
  const [isProfileActive] = useRoute("/profile/*");
  const [isFranchiseDashboardActive] = useRoute("/franchise-dashboard/*");
  
  // 관리자 또는 가맹점 주인인지 확인
  const isAdmin = isAuthenticated && user?.userType === 'admin';
  const isFranchiseOwner = isAuthenticated && user?.userType === 'franchise';
  const isFranchiseApproved = isFranchiseOwner && user?.isApproved;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-gray-800 bg-gradient-to-t from-gray-900/90 via-gray-900/70 to-gray-900/50 backdrop-blur-sm">
      <div className="flex justify-around items-center px-2 py-3">
        <Link href="/">
          <div className={`flex flex-col items-center ${isHomeActive ? 'text-primary' : 'text-gray-400'}`}>
            <Home className="w-5 h-5" />
            <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">{t.home}</span>
          </div>
        </Link>
        
        <Link href="/locations">
          <div className={`flex flex-col items-center ${isLocationsActive ? 'text-primary' : 'text-gray-400'}`}>
            <Search className="w-5 h-5" />
            <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">{t.locations}</span>
          </div>
        </Link>
        
        {/* 가맹점 주인이면 창고관리 메뉴 표시 */}
        {isFranchiseOwner ? (
          <Link href="/franchise-dashboard">
            <div className={`flex flex-col items-center ${isFranchiseDashboardActive ? 'text-primary' : 'text-gray-400'}`}>
              <Building className="w-5 h-5" />
              <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">
                {isFranchiseApproved ? "창고관리" : "승인대기"}
              </span>
            </div>
          </Link>
        ) : (
          <Link href="/contact">
            <div className={`flex flex-col items-center ${isContactActive ? 'text-primary' : 'text-gray-400'}`}>
              <MessageSquare className="w-5 h-5" />
              <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">{t.contact}</span>
            </div>
          </Link>
        )}
        
        {/* 일반 사용자와 비로그인 사용자에게만 가맹점 문의 메뉴 표시 */}
        {(!isAdmin && !isFranchiseOwner) && (
          <Link href="/franchise">
            <div className={`flex flex-col items-center ${isFranchiseActive ? 'text-primary' : 'text-gray-400'}`}>
              <Building className="w-5 h-5" />
              <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">{t.franchise}</span>
            </div>
          </Link>
        )}
        
        {/* 로그인 상태에 따라 다른 메뉴 표시 */}
        {isAuthenticated ? (
          <Link href="/profile">
            <div className={`flex flex-col items-center ${isProfileActive ? 'text-primary' : 'text-gray-400'}`}>
              <User className="w-5 h-5" />
              <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">{t.profile}</span>
            </div>
          </Link>
        ) : (
          <Link href="/login">
            <div className={`flex flex-col items-center text-gray-400`}>
              <User className="w-5 h-5" />
              <span className="mt-1 text-[10px] leading-tight whitespace-normal text-center break-words">{t.login}</span>
            </div>
          </Link>
        )}
      </div>
    </div>
  );
}
