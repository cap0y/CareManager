import { Package } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-800 px-4 py-6 mt-8">
      <div className="text-center">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
            <Package className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold text-white">SAVEBOX</span>
        </div>
        <p className="text-sm text-gray-400 mb-2">
          © 2025 SAVEBOX. All rights reserved.
        </p>
        <p className="text-xs text-gray-500">셀프 스토리지의 새로운 기준</p>
      </div>
    </footer>
  );
}
