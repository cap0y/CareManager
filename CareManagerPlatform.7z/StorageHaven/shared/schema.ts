import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firebaseUid: text("firebase_uid").unique(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  photoURL: text("photo_url"),
  phone: text("phone"),
  userType: text("user_type").default('user'),
  isApproved: boolean("is_approved").default(false),
  isSuperUser: boolean("is_super_user").default(false),
  franchiseInfo: jsonb("franchise_info"),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  partnerId: text("partner_id"), // 포트원 파트너 ID
  partnerStatus: text("partner_status").default('pending'), // 'pending', 'active', 'rejected'
  bankInfo: jsonb("bank_info"), // 파트너 정산용 은행 정보
  createdAt: timestamp("created_at").defaultNow(),
});

export const storageLocations = pgTable("storage_locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  district: text("district").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  features: jsonb("features").default([]),
  images: jsonb("images").default([]),
  isActive: boolean("is_active").default(true),
  ownerId: integer("owner_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const storageUnits = pgTable("storage_units", {
  id: serial("id").primaryKey(),
  locationId: integer("location_id").references(() => storageLocations.id),
  size: text("size").notNull(), // 'SB', 'M', 'L', etc.
  dimensions: text("dimensions").notNull(), // "100x100x100"
  dailyPrice: decimal("daily_price", { precision: 10, scale: 2 }),
  monthlyPrice: decimal("monthly_price", { precision: 10, scale: 2 }),
  quarterlyPrice: decimal("quarterly_price", { precision: 10, scale: 2 }),
  yearlyPrice: decimal("yearly_price", { precision: 10, scale: 2 }),
  unitNumber: text("unit_number"),
  isAvailable: boolean("is_available").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  storageUnitId: integer("storage_unit_id").references(() => storageUnits.id),
  subscriptionType: text("subscription_type").notNull(), // 'daily', 'monthly', 'quarterly', 'yearly'
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  status: text("status").default('pending'), // 'pending', 'active', 'cancelled', 'expired'
  paymentIntentId: text("payment_intent_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  firebaseUid: true,
  username: true,
  email: true,
  password: true,
  displayName: true,
  photoURL: true,
  phone: true,
  userType: true,
  isApproved: true,
  isSuperUser: true,
  franchiseInfo: true,
  partnerId: true,
  partnerStatus: true,
  bankInfo: true,
});

export const insertStorageLocationSchema = createInsertSchema(storageLocations).pick({
  name: true,
  address: true,
  city: true,
  district: true,
  latitude: true,
  longitude: true,
  features: true,
  images: true,
  ownerId: true,
});

export const insertStorageUnitSchema = createInsertSchema(storageUnits).pick({
  locationId: true,
  size: true,
  dimensions: true,
  dailyPrice: true,
  monthlyPrice: true,
  quarterlyPrice: true,
  yearlyPrice: true,
  unitNumber: true,
});

// 기존 자동 생성 스키마 대신 수동으로 정의
export const insertReservationSchema = z.object({
  userId: z.number().int(),
  storageUnitId: z.number().int(),
  subscriptionType: z.string(),
  startDate: z.union([
    z.string().transform(str => new Date(str)),
    z.date()
  ]),
  endDate: z.union([
    z.string().transform(str => new Date(str)),
    z.date()
  ]),
  totalAmount: z.union([
    z.number().transform(num => String(num)),
    z.string()
  ]),
  paymentIntentId: z.string().optional(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertStorageLocation = z.infer<typeof insertStorageLocationSchema>;
export type StorageLocation = typeof storageLocations.$inferSelect;

export type InsertStorageUnit = z.infer<typeof insertStorageUnitSchema>;
export type StorageUnit = typeof storageUnits.$inferSelect;

export type InsertReservation = z.infer<typeof insertReservationSchema>;
export type Reservation = typeof reservations.$inferSelect;
